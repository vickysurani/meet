﻿using azara.admin.Models.Account.Request;
using azara.admin.Models.Base.Response;
using azara.admin.Models.Const;
using azara.common.Services;
using azara.common.Shared;
using azara.models.Constants;
using Newtonsoft.Json;
using System.Text;

namespace azara.admin.Helpers
{
    public class AccountHelper
    {
        #region Login
        internal static async Task<dynamic> LoginAPI(LoginRequest loginRequest)
        {
            var ApiRequest = new LoginRequest
            {
                EmailId = loginRequest.EmailId,
                Password = loginRequest.Password
            };

            var url = $"{ApiEndPointConsts.Admin.AdminLogin}";
            var stringContent = new StringContent(JsonConvert.SerializeObject(ApiRequest), Encoding.Default, "application/json");
            var response = await Service.PostAPIWithoutToken(url, stringContent);
            if (response.meta.statusCode != StatusCodeConsts.Success)
            {
                return new CallAPIList()
                {
                    meta = response.meta,
                };
            }
            return new CallAPI()
            {
                meta = response.meta,
                data = response.data
            };
        }
        #endregion


        #region ForgotPassword API
        internal static async Task<dynamic> ForgotPasswordApi(ForgotPasswordRequest forgotPasswordRequest)
        {
            var url = $"{ApiEndPointConsts.Admin.ForgotPassword}";
            var stringContent = new StringContent(JsonConvert.SerializeObject(forgotPasswordRequest), Encoding.UTF8, "application/json");
            var response = await Service.PostAPIWithoutToken(url, stringContent);
            if (response.meta.statusCode != StatusCodeConsts.Success)
            {
                return new CallAPIList()
                {
                    meta = response.meta,
                };
            }
            return new CallAPI()
            {
                meta = response.meta,
                data = response.data
            };
        }
        #endregion


        #region Logout
        internal static async Task<dynamic> LogoutApi()
        {
            var url = $"{ApiEndPointConsts.Admin.Logout}";
            var response = await Service.GetAPIWithToken(url, TokenResponse.Token);
            if (response.meta.statusCode != StatusCodeConsts.Success)
            {
                return new CallAPIList()
                {
                    meta = response.meta,
                };
            }
            return new CallAPI()
            {
                meta = response.meta,
                data = response.data
            };
        }
        #endregion


        #region Reset Password
        internal static async Task<dynamic> ResetPasswordApi(ResetPasswordRequest resetPasswordRequest)
        {
            var url = $"{ApiEndPointConsts.Admin.ResetPassword}";
            var stringContent = new StringContent(JsonConvert.SerializeObject(resetPasswordRequest), Encoding.UTF8, "application/json");
            var response = await Service.PostAPIWithToken(url, stringContent, TokenResponse.Token);
            if (response.meta.statusCode != StatusCodeConsts.Success)
            {
                return new CallAPIList()
                {
                    meta = response.meta,
                };
            }
            return new CallAPI()
            {
                meta = response.meta,
                data = response.data
            };
        }
        #endregion
    }
}
