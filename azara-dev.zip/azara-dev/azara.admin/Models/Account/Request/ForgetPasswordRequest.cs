﻿using System.ComponentModel.DataAnnotations;

namespace azara.admin.Models.Account.Request
{
    public class ForgotPasswordRequest
    {
        [Required(ErrorMessage = "Please enter email address"), RegularExpression(@"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$", ErrorMessage = "Please enter valid email")]
        public string EmailId { get; set; }
    }

}
