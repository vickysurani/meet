﻿using azara.models.Requests.Base;
using System.ComponentModel.DataAnnotations;

namespace azara.admin.Models.Account.Request
{
    public class LoginRequest : PasswordRequest
    {
        [Required(ErrorMessage = "Please enter email address")]
        public string EmailId { get; set; }
    }

}
