﻿using System.ComponentModel.DataAnnotations;

namespace azara.admin.Models.Account.Request
{
    public class ResetPasswordRequest
    {
        [Required(ErrorMessage = "Please enter the password")]
        [DataType(DataType.Password)]
        [RegularExpression(@"^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$", ErrorMessage = "Please enter the valid password")]
        [StringLength(128, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 8)]
        public string Password { get; set; }

        [Compare("Password", ErrorMessage = "ConfirmPassword not matching with Password")]
        public string ConfirmPassword { get; set; }
    }
}
