﻿namespace azara.admin.Models.Base.Request
{
    public class ListRequest
    {
        public int PageNo { get; set; }
        public int PageSize { get; set; }

    }

    public class ListIdRequest : BaseIdRequest
    {
        public int PageNo { get; set; }
        public int PageSize { get; set; }

    }
}
