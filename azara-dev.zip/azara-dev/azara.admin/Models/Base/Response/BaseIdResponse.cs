﻿namespace azara.admin.Models.Base.Response
{
    public class BaseIdResponse
    {
        public string Id { get; set; }
    }
}
