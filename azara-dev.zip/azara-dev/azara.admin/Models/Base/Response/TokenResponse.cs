﻿namespace azara.admin.Models.Base.Response
{
    public class TokenResponse
    {
        public static string Token { get; set; }
    }
}
