﻿namespace azara.admin.Models.Const
{
    public class ApiEndPointConsts
    {
        const string Version = "v1/";

        public const string AdminBaseRoute = "https://localhost:7155/";
        public const string BaseRoute = "https://localhost:7234/api/" + Version;

        public class Admin
        {
            public const string AdminLogin = BaseRoute + "admin/login";

            public const string ForgotPassword = BaseRoute + "admin/forgot_password";

            public const string ResetPassword = BaseRoute + "admin/reset_password";

            public const string Logout = BaseRoute + "admin/logout";
        }
    }
}
