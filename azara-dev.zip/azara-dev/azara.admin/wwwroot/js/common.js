﻿function openProfileDropDown() {
    var className = $('.profile-menu').attr('class');
    if (className != undefined && className.includes('active')) {
        $('.profile-menu').removeClass('active');
    }
    if (className != undefined && !className.includes('active')) {
        $('.profile-menu').addClass('active');
    }
}

function removeSideNav(value) {
    var attr = $('#mySidenav');
    if (attr != undefined) {
        $('#mySidenav').css('display', 'none');
    }
    if (attr != undefined && value) {
        $('#mySidenav').css('display', 'block');
    }
}

window.ShowToastr = (type, message) => {
    toastr.options = {
        "closeButton": true
    }
    if (type === "success") {
        toastr.success(message, "Success");
    }
    if (type === "error") {
        toastr.error(message, "Error", { timeOut: 2000 });
    }
}

function showLoaderBg() {
    var attr = $('.main-pages');
    if (attr != undefined) {
        $('.main-pages').css('background-image', 'url("images/auth-bg.jpg")');
        $('.main-pages').css('background-size', 'cover');
        $('.main-pages').css('background-repeat', 'no-repeat');
    }
}