﻿using AutoMapper;
using azara.admin.Models.Const;
using azara.api.Controllers.Base;
using azara.api.Helpers;
using azara.models.Configs;
using azara.models.Constants;
using azara.models.Requests.Admin;
using azara.notify;
using azara.repository;
using azara.security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;

namespace azara.api.Controllers
{
    public class AdminController : BaseController
    {
        #region Object Declaration And Constructor
        public AdminController(
            IConfiguration configrations,
            IStringLocalizer<BaseController> Localizer,
            ICrypto Crypto,
            AzaraContext DbContext,
            IMapper Mapper)
        : base(Localizer, Crypto, DbContext, Mapper)
        {
        }

        #endregion

        #region 1. Admin Login

        [HttpPost(ActionsConsts.Admin.AdminLogin)]
        public async Task<IActionResult> AdminLoginAsync(
            [FromBody] AdminLoginRequest request,
            [FromServices] IOptions<AuthConfigs> AuthConfigOptions)
        {
            if (request == null) request = new AdminLoginRequest();
            if (ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new AdminHelpers(DbContext, Crypto, Mapper);
            request.UniqueId = Guid.NewGuid().ToString();
            var response = await helper.Login(request);

            if (response == null) return ErrorResponse();

            // Get Token
            response.Token = new AdminTokenHelpers(Crypto).GetAccessToken(AuthConfigOptions.Value, response, request.UniqueId);

            return OkResponse(response);
        }
        #endregion

        #region 2. Forgot Password
        [AllowAnonymous]
        [HttpPost(ActionsConsts.Admin.ForgotPassword)]
        public async Task<IActionResult> AdminForgotPasswordAsync([FromBody] AdminForgotPasswordRequest request, [FromServices] IMessages messages)
        {
            if (request == null) request = new AdminForgotPasswordRequest();
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            var helperResponse = await new AdminHelpers(DbContext, Crypto, Mapper).ForgotPassword(request);

            if (helperResponse == null) return ErrorResponse();

            string tokenUrl = $"{ApiEndPointConsts.AdminBaseRoute}/admin/reset-password/{helperResponse.Token}";
            // Send Email to admin
            new EmailHelpers(base.Localizer, messages).SendForgotPasswordEmail(helperResponse.Email, helperResponse.UserName, tokenUrl);

            return OkResponse(string.Format(Localizer["response_forgot_password"].Value, helperResponse.Email));
        }
        #endregion

        #region 3. Reset Password
        [AllowAnonymous]
        [HttpPost(ActionsConsts.Admin.ResetPassword)]
        public async Task<IActionResult> AdminResetPasswordAsync([FromBody] AdminResetPasswordRequest request)
        {
            if (request == null) request = new AdminResetPasswordRequest();
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new AdminHelpers(DbContext, Crypto, Mapper);
            var response = await helper.ResetPassword(request);

            if (response == null) return ErrorResponse();

            return OkResponse();
        }
        #endregion

        #region 4. Logout

        [Authorize, HttpGet(ActionsConsts.Admin.Logout)]
        public async Task<IActionResult> AdminLogoutAsync()
        {
            var adminId = GetUserId(User).ToString();
            var uniqueId = GetUniqueId(User);

            using var helper = new AdminHelpers(DbContext, Crypto, Mapper);
            var response = await helper.DeleteToken(new AdminDeleteTokenRequest
            {
                AdminId = adminId,
                UniqueId = uniqueId
            });

            if (response == null) return ErrorResponse();

            return OkResponse();
        }

        #endregion
    }
}
