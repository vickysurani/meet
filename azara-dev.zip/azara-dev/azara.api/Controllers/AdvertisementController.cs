﻿using AutoMapper;
using azara.api.Controllers.Base;
using azara.api.Helpers;
using azara.models.Constants;
using azara.models.Requests.Advertisement;
using azara.models.Requests.Base;
using azara.repository;
using azara.security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;

namespace azara.api.Controllers
{
    public class AdvertisementController : BaseController
    {
        #region Object Declaration And Constructor
        public AdvertisementController(
            IConfiguration configrations,
            IStringLocalizer<BaseController> Localizer,
            ICrypto Crypto,
            AzaraContext DbContext,
            IMapper Mapper)
        : base(Localizer, Crypto, DbContext, Mapper)
        {
        }

        #endregion

        #region 1. Advertisement Insert

        [Authorize, HttpPost(ActionsConsts.Advertisement.InsertAdvertisement)]
        public async Task<IActionResult> AdvertisementInsertAsync([FromBody] AdvertisementInsertRequest request)
        {
            if (request == null) request = new AdvertisementInsertRequest();
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new AdvertisementHelpers(DbContext, Crypto);
            var response = await helper.AdvertisementInsert(request);

            if (response == null) return ErrorResponse();

            DbContext.SaveChanges();

            return OkResponse();
        }
        #endregion

        #region 2. Advertisement Update
        [Authorize, HttpPost(ActionsConsts.Advertisement.UpdateAdvertisement)]
        public async Task<IActionResult> AdvertisementUpdateAsync([FromBody] AdvertisementUpdateRequest request)
        {
            if (request == null) request = new AdvertisementUpdateRequest();
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new AdvertisementHelpers(DbContext, Crypto);

            var response = await helper.AdvertisementUpdate(request);

            if (response == null) return ErrorResponse();

            return OkResponse(response);

        }
        #endregion

        #region 3. Get Advertisement List
        [Authorize, HttpPost(ActionsConsts.Advertisement.GetAdvertisementList)]
        public async Task<IActionResult> AdvertisementGetListAsync([FromBody] PaginationRequest request)
        {
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new AdvertisementHelpers(DbContext, Crypto);

            var response = await helper.AdvertisementGetList(request);
            if (response is null) return ErrorResponse();

            return OkResponse(response);
        }
        #endregion

        #region 6. Advertisement Delete
        [HttpPost(ActionsConsts.Advertisement.DeleteAdvertisement)]
        public async Task<IActionResult> AdvertisementDeleteAsync([FromBody] BaseIdRequest request)
        {
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new AdvertisementHelpers(DbContext, Crypto);

            var response = await helper.AdvertisementDelete(request);
            if (response is null) return ErrorResponse();

            return OkResponse(response);
        }
        #endregion
    }
}
