﻿using AutoMapper;
using azara.api.Filter;
using azara.models.Constants;
using azara.models.Entities;
using azara.repository;
using azara.security;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace azara.api.Controllers.Base;
[ServiceFilter(typeof(ExceptionFilter))]
[EnableCors("CorsPolicy")]
[Route(ActionsConsts.ApiVersion)]
[ApiController]
public class BaseController : Controller
{
    #region Constructor and Object Declaration

    public IRepository<AzaraContext, UserEntity> UserEntityRepository;
    protected IStringLocalizer<BaseController> Localizer { get; set; }

    protected ICrypto Crypto { get; set; }

    public AzaraContext DbContext { get; set; }

    public IMapper Mapper { get; set; }

    public BaseController(
       IStringLocalizer<BaseController> Localizer,
       ICrypto Crypto,
       AzaraContext DbContext,
       IMapper Mapper)
    {
        this.Localizer = Localizer;
        this.Crypto = Crypto;
        this.DbContext = DbContext;
        this.Mapper = Mapper;
    }

    #endregion

    #region 1.Get current user's data using Token

    protected bool IsLoggedIn(ClaimsPrincipal User) => User.Identity.IsAuthenticated;

    protected Guid GetUserId(ClaimsPrincipal User)
    {
        var user_id = User.Claims.Where(x => x.Type == JwtRegisteredClaimNames.Sid)?.FirstOrDefault().Value;

        if (string.IsNullOrEmpty(user_id)) return Guid.Empty;  // Early return

        return Guid.Parse(Crypto.Decrypt(user_id));
    }

    protected string GetUserEmail(ClaimsPrincipal User)
    {
        var email = User.Claims.Where(x => x.Type == ClaimTypes.Email)?.FirstOrDefault().Value;

        if (string.IsNullOrEmpty(email)) return String.Empty;  // Early return

        return Crypto.Decrypt(email);
    }

    protected string GetUserName(ClaimsPrincipal User)
    {
        var email = User.Claims.Where(x => x.Type == ClaimTypes.GivenName)?.FirstOrDefault().Value;

        if (string.IsNullOrEmpty(email)) return String.Empty;  // Early return

        return Crypto.Decrypt(email);
    }

    protected string GetUniqueId(ClaimsPrincipal User)
    {
        var uniqueId = User.Claims.Where(x => x.Type == JwtRegisteredClaimNames.Jti)?.FirstOrDefault().Value;

        if (string.IsNullOrEmpty(uniqueId)) return String.Empty;  // Early return

        return Crypto.Decrypt(uniqueId);
    }


    protected string GetUserRole(ClaimsPrincipal User)
    {
        var role = User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.Role)?.Value;

        if (string.IsNullOrEmpty(role)) return String.Empty;  // Early return

        return Crypto.Decrypt(role);
    }

    #endregion

    #region 2. OkResponse

    protected IActionResult OkResponse() => Ok(new
    {
        meta = new
        {
            message = Localizer["ok_response_successful"].Value,
            statusCode = 200
        }
    });

    protected IActionResult OkResponse(string message) => Ok(new
    {
        meta = new { message = Localizer[message].Value, statusCode = 200 }
    });

    protected IActionResult OkResponse(string message, object data) => Ok(new
    {
        meta = new { message = Localizer[message].Value, statusCode = 200 },
        data = data
    });

    protected IActionResult OkResponse(object data) => Ok(new
    {
        meta = new { message = Localizer["ok_response_successful"].Value, statusCode = 200 },
        data = data
    });

    protected IActionResult OkResponse(IEnumerable<dynamic> details)
    {
        var data = new { details };
        return Ok(new
        {
            meta = new { message = Localizer["ok_response_successful"].Value, statusCode = 200 },
            data
        });
    }

    #endregion

    #region 3. Failed Response

    protected IActionResult ErrorResponse() => throw new ApiException("error_something_went_wrong", 400);

    protected IActionResult ErrorResponse(string message) => throw new ApiException(message, 400);

    protected IActionResult ErrorResponse(string message, int statusCode) => throw new ApiException(message, statusCode);

    protected IActionResult ErrorResponse(Microsoft.AspNetCore.Mvc.ModelBinding.ModelStateDictionary ModelState)
    {
        string message = string.Join("; ", ModelState.SelectMany(x => x.Value.Errors).Select(x => Localizer[x.ErrorMessage].Value));
        throw new ApiException(message, 400);
    }

    protected IActionResult ErrorResponse(Microsoft.AspNetCore.Mvc.ModelBinding.ModelStateDictionary ModelState, int statusCode)
    {
        string message = string.Join("; ", ModelState.SelectMany(x => x.Value.Errors).Select(x => Localizer[x.ErrorMessage].Value));
        throw new ApiException(message, statusCode);
    }

    #endregion
}
