﻿using AutoMapper;
using azara.api.Controllers.Base;
using azara.api.Helpers;
using azara.models.Constants;
using azara.models.Requests.Base;
using azara.models.Requests.Blog;
using azara.repository;
using azara.security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;

namespace azara.api.Controllers
{
    public class BlogController : BaseController
    {
        #region Object Declaration And Constructor
        public BlogController(
            IConfiguration configrations,
            IStringLocalizer<BaseController> Localizer,
            ICrypto Crypto,
            AzaraContext DbContext, 
            IMapper Mapper)
        : base(Localizer, Crypto, DbContext, Mapper)
        {
        }

        #endregion

        #region 1. Blog Insert

        [Authorize, HttpPost(ActionsConsts.Blog.InsertBlog)]
        public async Task<IActionResult> BlogInsertAsync([FromBody] BlogInsertRequest request)
        {
            if (request == null) request = new BlogInsertRequest();
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new BlogHelpers(DbContext, Crypto);
            var response = await helper.BlogInsert(request);

            if (response == null) return ErrorResponse();

            DbContext.SaveChanges();

            return OkResponse();
        }
        #endregion

        #region 4. Get Blog List
        [Authorize, HttpPost(ActionsConsts.Blog.GetBlogList)]
        public async Task<IActionResult> BlogGetListAsync([FromBody] PaginationRequest request)
        {
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new BlogHelpers(DbContext, Crypto);

            var response = await helper.BlogGetList(request);
            if (response is null) return ErrorResponse();

            return OkResponse(response);
        }
        #endregion

        #region 6. Blog Delete
        [HttpPost(ActionsConsts.Blog.DeleteBlog)]
        public async Task<IActionResult> BlogDeleteAsync([FromBody] BaseIdRequest request)
        {
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new BlogHelpers(DbContext, Crypto);

            var response = await helper.BlogDelete(request);
            if (response is null) return ErrorResponse();

            return OkResponse(response);
        }
        #endregion
    }
}
