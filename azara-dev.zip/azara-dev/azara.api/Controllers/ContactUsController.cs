﻿using AutoMapper;
using azara.api.Controllers.Base;
using azara.api.Helpers;
using azara.models.Constants;
using azara.models.Requests.ContactUs;
using azara.repository;
using azara.security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;

namespace azara.api.Controllers
{
    public class ContactUsController : BaseController
    {
        #region Object Declaration And Constructor
        public ContactUsController(
            IConfiguration configrations,
            IStringLocalizer<BaseController> Localizer,
            ICrypto Crypto,
            AzaraContext DbContext,
            IMapper Mapper)
        : base(Localizer, Crypto, DbContext, Mapper)
        {
        }

        #endregion

        #region 1. Contact Insert

        [AllowAnonymous, HttpPost(ActionsConsts.ContactUs.AddContactUs)]
        public async Task<IActionResult> ProductInsertAsync([FromBody] ContactUsAddRequest request)
        {
            if (request == null) request = new ContactUsAddRequest();
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new ContactUsHelpers(DbContext, Crypto);
            var response = await helper.ContactUs(request);

            if (response == null) return ErrorResponse();

            DbContext.SaveChanges();

            return OkResponse();
        }
        #endregion
    }
}
