﻿using AutoMapper;
using azara.api.Controllers.Base;
using azara.api.Helpers;
using azara.models.Constants;
using azara.models.Requests.ProductCategory;
using azara.repository;
using azara.security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;

namespace azara.api.Controllers
{
    public class ProductCategoryController : BaseController
    {
        #region Object Declaration And Constructor
        public ProductCategoryController(
            IConfiguration configrations,
            IStringLocalizer<BaseController> Localizer,
            ICrypto Crypto,
            AzaraContext DbContext,
            IMapper Mapper)
        : base(Localizer, Crypto, DbContext, Mapper)
        {
        }

        #endregion

        #region 1. Product Category Insert

        [Authorize, HttpPost(ActionsConsts.ProductCategory.InsertProductCategory)]
        public async Task<IActionResult> ProductInsertAsync([FromBody] ProductCategoryInsertRequest request)
        {
            if (request == null) request = new ProductCategoryInsertRequest();
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new ProductCategoryHelpers(DbContext, Crypto);
            var response = await helper.ProductCategoryInsert(request);

            if (response == null) return ErrorResponse();

            DbContext.SaveChanges();

            return OkResponse();
        }
        #endregion

        #region 2. Product Category Update
        [Authorize, HttpPost(ActionsConsts.ProductCategory.UpdateProductCategory)]
        public async Task<IActionResult> ProductCategoryUpdateAsync([FromBody] ProductCategoryUpdateRequest request)
        {
            if (request == null) request = new ProductCategoryUpdateRequest();
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new ProductCategoryHelpers(DbContext, Crypto);

            var response = await helper.ProductCategoryUpdate(request);

            if (response == null) return ErrorResponse();

            return OkResponse(response);

        }
        #endregion
    }
}
