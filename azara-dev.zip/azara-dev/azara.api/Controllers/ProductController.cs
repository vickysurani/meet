﻿using AutoMapper;
using azara.api.Controllers.Base;
using azara.api.Helpers;
using azara.models.Constants;
using azara.models.Requests.Base;
using azara.models.Requests.Product;
using azara.repository;
using azara.security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;

namespace azara.api.Controllers
{
    public class ProductController : BaseController
    {
        #region Object Declaration And Constructor
        public ProductController(
            IConfiguration configrations,
            IStringLocalizer<BaseController> Localizer,
            ICrypto Crypto,
            AzaraContext DbContext,
            IMapper Mapper)
        : base(Localizer, Crypto, DbContext, Mapper)
        {
        }

        #endregion

        #region 1. Product Insert

        [Authorize, HttpPost(ActionsConsts.Product.InsertProduct)]
        public async Task<IActionResult> ProductInsertAsync([FromBody] ProductInsertRequest request)
        {
            if (request == null) request = new ProductInsertRequest();
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new ProductHelpers(DbContext, Crypto);
            var response = await helper.ProductInsert(request);

            if (response == null) return ErrorResponse();

            DbContext.SaveChanges();

            return OkResponse();
        }
        #endregion

        #region 2. Product Update
        [Authorize, HttpPost(ActionsConsts.Product.UpdateProduct)]
        public async Task<IActionResult> ProductUpdateAsync([FromBody] ProductUpdateRequest request)
        {
            if (request == null) request = new ProductUpdateRequest();
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new ProductHelpers(DbContext, Crypto);

            var response = await helper.ProductUpdate(request);

            if (response == null) return ErrorResponse();

            return OkResponse(response);

        }
        #endregion

        #region 3. Product Get By Id
        [Authorize, HttpPost(ActionsConsts.Product.ProductGetById)]
        public async Task<IActionResult> ProductGetBtyIdAsync([FromBody] BaseRequiredIdRequest request)
        {
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new ProductHelpers(DbContext, Crypto);

            var response = await helper.ProductGetById(request);

            return OkResponse(response);
        }
        #endregion

        #region 4. Get Product List
        [HttpPost(ActionsConsts.Product.ProductGetList)]
        public async Task<IActionResult> ProductGetListAsync([FromBody] PaginationRequest request)
        {
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new ProductHelpers(DbContext, Crypto);

            var response = await helper.ProductGetList(request);
            if (response is null) return ErrorResponse();

            return OkResponse(response);
        }
        #endregion

        #region 6. Product Delete
        [HttpPost(ActionsConsts.Product.ProductDelete)]
        public async Task<IActionResult> ProductDeleteAsync([FromBody] BaseIdRequest request)
        {
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new ProductHelpers(DbContext, Crypto);

            var response = await helper.ProductDelete(request);
            if (response is null) return ErrorResponse();

            return OkResponse(response);
        }
        #endregion
    }
}
