﻿using AutoMapper;
using azara.api.Controllers.Base;
using azara.api.Helpers;
using azara.models.Constants;
using azara.models.Requests.Base;
using azara.models.Requests.Store;
using azara.repository;
using azara.security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;

namespace azara.api.Controllers
{
    public class StoreController : BaseController
    {
        #region Object Declaration And Constructor
        public StoreController(
            IConfiguration configrations,
            IStringLocalizer<BaseController> Localizer,
            ICrypto Crypto,
            AzaraContext DbContext,
            IMapper Mapper)
        : base(Localizer, Crypto, DbContext, Mapper)
        {
        }

        #endregion

        #region 1. Store Insert

        [Authorize, HttpPost(ActionsConsts.Store.InsertStore)]
        public async Task<IActionResult> ProductInsertAsync([FromBody] StoreInsertRequest request)
        {
            if (request == null) request = new StoreInsertRequest();
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new StoreHelpers(DbContext, Crypto);
            var response = await helper.StoreInsert(request);

            if (response == null) return ErrorResponse();

            DbContext.SaveChanges();

            return OkResponse();
        }
        #endregion

        #region 2. Store Update
        [Authorize, HttpPost(ActionsConsts.Store.UpdateStore)]
        public async Task<IActionResult> StoreUpdateAsync([FromBody] StoreUpdateRequest request)
        {
            if (request == null) request = new StoreUpdateRequest();
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new StoreHelpers(DbContext, Crypto);

            var response = await helper.StoreUpdate(request);

            if (response == null) return ErrorResponse();

            return OkResponse(response);

        }
        #endregion

        #region 3. Store Get By Id
        [Authorize, HttpPost(ActionsConsts.Store.StoreGetById)]
        public async Task<IActionResult> StoreGetBtyIdAsync([FromBody] BaseRequiredIdRequest request)
        {
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new StoreHelpers(DbContext, Crypto);

            var response = await helper.StoreGetById(request);

            return OkResponse(response);
        }
        #endregion

        #region 4. Get Store List
        [Authorize, HttpPost(ActionsConsts.Store.StoreGetList)]
        public async Task<IActionResult> StoreGetListAsync([FromBody] PaginationRequest request)
        {
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new StoreHelpers(DbContext, Crypto);

            var response = await helper.StoreGetList(request);
            if (response is null) return ErrorResponse();

            return OkResponse(response);
        }
        #endregion

    }
}
