﻿using AutoMapper;
using azara.api.Controllers.Base;
using azara.api.Helpers;
using azara.models.Configs;
using azara.models.Constants;
using azara.models.Requests.User;
using azara.models.Responses.User;
using azara.notify;
using azara.repository;
using azara.security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace azara.api.Controllers
{
    public class UserController : BaseController
    {
        #region Object Declaration And Constructor
        public UserController(
            IConfiguration configrations,
            IStringLocalizer<BaseController> Localizer,
            ICrypto Crypto,
            AzaraContext DbContext,
            IMapper Mapper)
        : base(Localizer, Crypto, DbContext, Mapper)
        {
        }

        #endregion

        #region 1. User SignIn

        [AllowAnonymous,HttpPost(ActionsConsts.User.UserLogin)]
        public async Task<IActionResult> UserLoginAsync(
            [FromBody] UserSignInRequest request,
            [FromServices] IOptions<AuthConfigs> AuthConfigOptions)
        {
            if (request == null) request = new UserSignInRequest();
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new UserHelpers(DbContext, Crypto, Mapper);
            var helperResponse = await helper.Login(request);

            if (helperResponse == null) return ErrorResponse();
            if (!helperResponse.IsSuccess) return ErrorResponse(helperResponse.ErrorMessage);

            var response = JsonConvert.DeserializeObject<UserSignInResponse>(helperResponse.Data);

            // Get Token
            response.Token = new UserTokenHelpers(Crypto).GetAccessToken(AuthConfigOptions.Value, response, request.UniqueId);  
            return OkResponse(response);
        }
        #endregion

        #region 2. User SignUp
        [AllowAnonymous,HttpPost(ActionsConsts.User.UserSignUp)]
        public async Task<IActionResult> UserRegisterAsync([FromBody] UserSignUpRequest request)
        {
            if (request == null) request = new UserSignUpRequest();
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new UserHelpers(DbContext, Crypto, Mapper);
            var response = await helper.SignUp(request);

            if (response == null) return ErrorResponse();

            DbContext.SaveChanges();
            return OkResponse(response);
        }
        #endregion

        #region 3. Forgot Password

        [AllowAnonymous, HttpPost(ActionsConsts.User.ForgotPassword)]
        public async Task<IActionResult> UserForgotPasswordAsync(
            [FromBody] UserForgotPasswordRequest request,
            [FromServices] IMessages messages)
        {
            if (request == null) request = new UserForgotPasswordRequest();
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            var helperResponse = await new UserHelpers(DbContext, Crypto, Mapper).ForgotPassword(request);

            if (helperResponse == null) return ErrorResponse();
            if (!helperResponse.IsSuccess) return ErrorResponse(helperResponse.ErrorMessage);

            var response = JsonConvert.DeserializeObject<UserForgotPasswordResponse>(helperResponse.Data);

            // Send Email to user
            new EmailHelpers(base.Localizer, messages).SendForgotPasswordEmail(response.EmailId, response.UserName, response.Otp);

            return OkResponse(string.Format(Localizer["response_forgot_password"].Value, response.EmailId));
        }
        #endregion

        #region 4. User Otp Verify

        [Authorize, HttpPost(ActionsConsts.User.OtpVerify)]
        public async Task<IActionResult> AdminOtpVerifyAsync([FromBody] UserOtpVerifyRequest request)
        {
            var email = GetUserEmail(User);
            request.EmailId = email;

            using var helper = new UserHelpers(DbContext, Crypto, Mapper);
            var response = await helper.OtpVerify(request);

            if (response == null) return ErrorResponse();
            if (!response.IsSuccess) return ErrorResponse(response.ErrorMessage);

            return OkResponse();
        }

        #endregion

        #region 5. Reset Password

        [Authorize, HttpPost(ActionsConsts.User.ResetPassword)]
        public async Task<IActionResult> AdminResetPasswordAsync([FromBody] UserResetPasswordRequest request)
        {
            if (request == null) request = new UserResetPasswordRequest();
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new UserHelpers(DbContext, Crypto, Mapper);
            var response = await helper.ResetPassword(request);

            if (response == null) return ErrorResponse();

            return OkResponse();
        }

        #endregion

        #region 6. Change Password

        [Authorize, HttpPost(ActionsConsts.User.ChangePassword)]
        public async Task<IActionResult> UserChangePasswordAsync(
            [FromBody] UserChangePasswordRequest request,
            [FromServices] IMessages messages)
        {
            if (request == null) request = new UserChangePasswordRequest();
            if (!ModelState.IsValid)
                return ErrorResponse(ModelState);

            if (request.CurrentPassword.Equals(request.ConfirmPassword))
                return ErrorResponse("error_current_password_same_with_new_password");

            request.UserId = GetUserId(User);
            using var helper = new UserHelpers(DbContext, Crypto, Mapper);
            var response = await helper.ChangePassword(request);

            if (response == null) return ErrorResponse();

            if (!string.IsNullOrEmpty(response.ErrorMessage))
            {
                return ErrorResponse(response.ErrorMessage);
            }
            // Send Email
            //new EmailHelpers(base.Localizer, messages).SendUserChangePasswordEmail(
            //    GetUserEmail(User),
            //    GetUserName(User));

            return OkResponse("response_password_changed_successfully");
        }

        #endregion

        #region 7. Update Profile

        [Authorize, HttpPost(ActionsConsts.User.UpdateProfile)]
        public async Task<IActionResult> EditProfileAsync([FromBody] UserUpdateProfileRequest request,
             [FromServices] IOptions<AuthConfigs> AuthConfigOptions)
        {
            if (request == null) request = new UserUpdateProfileRequest();

            if (ModelState.IsValid)
                return ErrorResponse(ModelState);

            using var helper = new UserHelpers(DbContext, Crypto, Mapper);
            request.UniqueId = GetUniqueId(User);

            var response = await helper.EditProfile(request);

            //response.Token = new AdminTokenHelpers(Crypto).GetAccessToken(AuthConfigOptions.Value, response, request.UniqueId);

            if (response == null) return ErrorResponse();

            return OkResponse(response);
        }
        #endregion

        #region 8. Logout

        [Authorize, HttpGet(ActionsConsts.User.Logout)]
        public async Task<IActionResult> UserLogoutAsync()
        {
            var adminId = GetUserId(User).ToString();
            var uniqueId = GetUniqueId(User);

            using var helper = new UserHelpers(DbContext, Crypto, Mapper);
            var response = await helper.DeleteToken(new UserDeleteTokenRequest 
            { 
                UserId = adminId, 
                UniqueId = uniqueId 
            });

            if (response == null) return ErrorResponse();

            return OkResponse();
        }

        #endregion

        #region 9. Get Profile

        [Authorize, HttpGet(ActionsConsts.User.UserProfile)]
        public async Task<IActionResult> GetUserProfileAsync()
        {
            Guid userId = GetUserId(User);
            if (userId == new Guid() && userId == Guid.Empty)
                return ErrorResponse();

            using var helper = new UserHelpers(DbContext, Crypto, Mapper);
            var helperResponse = await helper.GetUserProfile(userId);

            if (helperResponse == null) return ErrorResponse();

            return OkResponse(helperResponse);
        }
        #endregion
    }
}
