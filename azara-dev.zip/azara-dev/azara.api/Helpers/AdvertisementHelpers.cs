﻿using azara.api.Filter;
using azara.models.Entities;
using azara.models.Requests.Advertisement;
using azara.models.Requests.Base;
using azara.models.Responses.Advertisement;
using azara.models.Responses.Base;
using azara.repository;
using azara.security;
using Microsoft.AspNetCore.Mvc;

namespace azara.api.Helpers
{
    public class AdvertisementHelpers : IDisposable
    {
        #region Constructor
        AzaraContext DbContext { get; set; }
        ICrypto Crypto { get; set; }

        public AdvertisementHelpers(
            AzaraContext DbContext,
            ICrypto Crypto)
        {
            this.DbContext = DbContext;
            this.Crypto = Crypto;
        }

        #endregion

        #region Calculate Total Pages

        public static int CalculateTotalPages(
            int total,
            int? pageSize)
        {
            var pages = Convert.ToDecimal(total) / Convert.ToDecimal(pageSize);
            var response = pages < 1 ? 1 : Convert.ToInt32(Math.Ceiling(pages));

            return response;
        }

        #endregion Calculate Total Pages

        #region 1. Insert Advertisement

        public async Task<BaseResponse> AdvertisementInsert([FromBody] AdvertisementInsertRequest request)
        {
            if (DbContext.Advertisements.Any(x => x.AdvertisementTitle.ToLower().Equals(request.AdvertisementTitle.ToLower())))
                return await Task.FromResult(new BaseResponse { IsSuccess = false, ErrorMessage = "error_title_exist" });

            await DbContext.AddRangeAsync(new AdvertisementsEntity
            {
                AdvertisementTitle = request.AdvertisementTitle,
                AdvertisementBannerImage = request.AdvertisementBannerImage,
                Description = request.Description,
                StoreId = request.StoreId
            });

            await DbContext.SaveChangesAsync();

            return new BaseResponse { IsSuccess = true };
        }

        #endregion

        #region 2. Update Advertisement
        public async Task<AdvertisementUpdateResponse> AdvertisementUpdate([FromBody] AdvertisementUpdateRequest request)
        {
            var ad = DbContext.Advertisements.FirstOrDefault(x => x.Id.ToString().Equals(request.Id.ToString()));

            if (ad == null)
                throw new ApiException("error_advertisement_not_found");

            ad.AdvertisementTitle = request.AdvertisementTitle ?? ad.AdvertisementTitle;
            ad.AdvertisementBannerImage = request.AdvertisementBannerImage ?? ad.AdvertisementBannerImage;
            ad.Description = request.Description ?? ad.Description;
            ad.StoreId = request.StoreId ?? ad.StoreId;

            var response = new AdvertisementUpdateResponse
            {
                AdvertisementTitle = ad.AdvertisementTitle,
                AdvertisementBannerImage = ad.AdvertisementBannerImage,
                Description = ad.Description,
                StoreId = ad.StoreId
            };

            DbContext.SaveChanges();

            return response;
        }
        #endregion

        #region 3. Get Advertisement List
        public async Task<PaginationResponse> AdvertisementGetList([FromBody] PaginationRequest request)
        {
            var adList = (from A in DbContext.Advertisements
                               join S in DbContext.Stores on A.StoreId equals S.Id
                               select new
                               {
                                   Id = A.Id,
                                   AdvertisementTitle = A.AdvertisementTitle,
                                   AdvertisementBannerImage = A.AdvertisementBannerImage,
                                   Description = A.Description,
                                   StoreName = S.Name,
                                   StoreImage = S.Image,
                                   StoreLocation = S.Location
                               }).ToList();

            if (adList == null)
                throw new ApiException("error_advertisement_not_found");

            var total = adList.Count();
            var totalPages = AdvertisementHelpers.CalculateTotalPages(total, request.PageSize);
            var eventPaginationList = adList.Skip(request.PageNo * request.PageSize).Take(request.PageSize);

            var response = new
            {
                Total = total,
                TotalPages = totalPages,
                PageSize = request.PageSize,
                Offset = request.PageNo,
                Details = eventPaginationList
            };

            return new PaginationResponse
            {
                Total = response.Total,
                TotalPages = response.Total,
                OffSet = response.Offset,
                Details = response.Details
            };

        }
        #endregion

        #region 4. Delete Advertisement
        public async Task<BaseResponse> AdvertisementDelete([FromBody] BaseIdRequest request)
        {
            var ad = DbContext.Advertisements.FirstOrDefault(x => x.Id.Equals(request.Id));

            DbContext.Advertisements.Remove(ad);

            DbContext.SaveChanges();
            return new BaseResponse { IsSuccess = true };
        }
        #endregion 

        #region Dispose

        public void Dispose() => GC.SuppressFinalize(this);

        #endregion Dispose
    }
}
