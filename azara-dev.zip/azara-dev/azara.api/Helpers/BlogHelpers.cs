﻿using azara.api.Filter;
using azara.models.Constants;
using azara.models.Entities;
using azara.models.Requests.Base;
using azara.models.Requests.Blog;
using azara.models.Responses.Base;
using azara.repository;
using azara.security;
using Microsoft.AspNetCore.Mvc;

namespace azara.api.Helpers
{
    public class BlogHelpers : IDisposable
    {
        #region Constructor
        AzaraContext DbContext { get; set; }
        ICrypto Crypto { get; set; }

        public BlogHelpers(
            AzaraContext DbContext,
            ICrypto Crypto)
        {
            this.DbContext = DbContext;
            this.Crypto = Crypto;
        }

        #endregion

        #region Calculate Total Pages

        public static int CalculateTotalPages(
            int total,
            int? pageSize)
        {
            var pages = Convert.ToDecimal(total) / Convert.ToDecimal(pageSize);
            var response = pages < 1 ? 1 : Convert.ToInt32(Math.Ceiling(pages));

            return response;
        }

        #endregion Calculate Total Pages

        #region 1. Insert blog

        public async Task<BaseResponse> BlogInsert([FromBody] BlogInsertRequest request)
        {
            if (DbContext.Blogs.Any(x => x.Title.ToLower().Equals(request.Title.ToLower())))
                return await Task.FromResult(new BaseResponse { IsSuccess = false, ErrorMessage = "error_title_exist" });

            await DbContext.AddRangeAsync(new BlogsEntity
            {
                Image = request.Image,
                Title = request.Title,
                PublishedDate = request.PublishedDate,
                AuthorName = request.AuthorName,
                Descriptions = request.Descriptions,
                Created = SettingConsts.CurrentDateTime
            }); ;

            await DbContext.SaveChangesAsync();

            return new BaseResponse { IsSuccess = true };
        }

        #endregion

        #region 2. Get Product List
        public async Task<PaginationResponse> BlogGetList([FromBody] PaginationRequest request)
        {
            var blogList = DbContext.Blogs.ToList();

            if (blogList == null)
                throw new ApiException("error_blog_not_found");

            var total = blogList.Count();
            var totalPages = BlogHelpers.CalculateTotalPages(total, request.PageSize);
            var eventPaginationList = blogList.Skip(request.PageNo * request.PageSize).Take(request.PageSize);

            var response = new
            {
                Total = total,
                TotalPages = totalPages,
                PageSize = request.PageSize,
                Offset = request.PageNo,
                Details = eventPaginationList
            };

            return new PaginationResponse
            {
                Total = response.Total,
                TotalPages = response.Total,
                OffSet = response.Offset,
                Details = response.Details
            };

        }
        #endregion

        #region 3. Delete Blog
        public async Task<BaseResponse> BlogDelete([FromBody] BaseIdRequest request)
        {
            var blog = DbContext.Blogs.FirstOrDefault(x => x.Id.Equals(request.Id));

            DbContext.Blogs.Remove(blog);

            DbContext.SaveChanges();
            return new BaseResponse { IsSuccess = true };
        }
        #endregion 

        #region Dispose

        public void Dispose() => GC.SuppressFinalize(this);

        #endregion Dispose
    }
}
