﻿using azara.models.Entities;
using azara.models.Requests.ContactUs;
using azara.models.Responses.Base;
using azara.repository;
using azara.security;
using Microsoft.AspNetCore.Mvc;

namespace azara.api.Helpers
{
    public class ContactUsHelpers : IDisposable
    {
        #region Constructor
        AzaraContext DbContext { get; set; }
        ICrypto Crypto { get; set; }

        public ContactUsHelpers(
            AzaraContext DbContext,
            ICrypto Crypto)
        {
            this.DbContext = DbContext;
            this.Crypto = Crypto;
        }

        #endregion

        #region 1. Insert Product

        public async Task<BaseResponse> ContactUs([FromBody] ContactUsAddRequest request)
        {
            await DbContext.AddRangeAsync(new ContactUsEntity
            {
                Name = request.Name,
                EmailId = request.EmailId,
                Description = request.Description
            });

            await DbContext.SaveChangesAsync();

            return new BaseResponse { IsSuccess = true };
        }

        #endregion

        #region Dispose

        public void Dispose() => GC.SuppressFinalize(this);

        #endregion Dispose
    }
}
