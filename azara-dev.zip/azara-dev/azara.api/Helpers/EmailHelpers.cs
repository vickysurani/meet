﻿using azara.api.Controllers.Base;
using azara.models.Configs;
using azara.notify;
using azara.notify.Models;
using Microsoft.Extensions.Localization;

namespace azara.api.Helpers
{
    public class EmailHelpers
    {
        #region Object Declarations And Constructor

        private IStringLocalizer<BaseController> Localizer { get; set; }

        private IMessages Messages { get; set; }

        private EmailConfigs emailConfigs { get; set; }

        public EmailHelpers(IStringLocalizer<BaseController> Localizer, IMessages Messages)
        {
            this.Localizer = Localizer;
            this.Messages = Messages;
        }

        #endregion Object Declarations And Constructor

        #region Send Account related mail

        //public void SendAdminSeedEmail(string email, string name, string url)
        //{
        //    SendEmail(email, $"{Localizer["email_admin_invite"].Value}", DesignEmail($"{Localizer["email_admin_invite"].Value}", $@"<tr><td style=""font-weight: 500; color: #292929; font-family: 'Nunito', sans-serif;"">Hi {name},</td></tr><tr><td style="" line-height: 0px;"" height=""16""></td></tr><tr><td style=""font-family: 'Nunito', sans-serif;"">You are invited to manage the {Localizer["app_name"].Value}. Click login button to manage {Localizer["app_name"].Value}</td></tr><tr><td style="" line-height: 0px;"" height=""32""></td></tr><tr align=""center""><td><a href=""{url}"" style=""font-family: 'Nunito', sans-serif; padding: 12px; min-width: 216px; display: inline-block; background: #F5B041; border-radius: 4px; font-size: 14px; line-height: 20px; color: #fff;"">Login</a></td></tr><tr><td style="" line-height: 0px;"" height=""32""></td></tr>"));
        //}

        //public void SendAdminInviteEmail(string email, string name, string username, string password, string url)
        //{
        //    SendEmail(email, $"{Localizer["email_admin_invite"].Value}", DesignEmail($"{Localizer["email_admin_invite"].Value}", $@"<tr><td style=""font-weight: 500; color: #292929; font-family: 'Nunito', sans-serif;"">Hi {name},</td></tr><tr><td style="" line-height: 0px;"" height=""16""></td></tr><tr><td style=""line-height: 0px;"" height=""16"">Username: <b>{username}</b></td></tr><tr><td style=""line-height: 0px;"" height=""16"">Password: <b>{password}</b></td></tr><tr><td style=""font-family: 'Nunito', sans-serif;"">You are invited to manage the {Localizer["app_name"].Value}. Click login button to manage {Localizer["app_name"].Value}</td></tr><tr><td style="" line-height: 0px;"" height=""32""></td></tr><tr align=""center""><td><a href=""{url}"" style=""font-family: 'Nunito', sans-serif; padding: 12px; min-width: 216px; display: inline-block; background: #F5B041; border-radius: 4px; font-size: 14px; line-height: 20px; color: #fff;"">Login</a></td></tr><tr><td style="" line-height: 0px;"" height=""32""></td></tr>"));
        //}

        public void SendUserChangePasswordEmail(string email, string username)
        {
            SendEmail(email, $"{Localizer["email_sub_change_password"].Value}", DesignEmail($"{Localizer["email_sub_change_password"].Value}", $@"<tr><td style=""font-weight: 500; color: #292929; font-family: 'Nunito', sans-serif;"">Hi {username},</td></tr><tr><td style="" line-height: 0px;"" height=""16""></td></tr><tr><td style=""font-family: 'Nunito', sans-serif;"">Your password for the {Localizer["app_name"].Value} account has been updated recently. Ignore this email if you have made this changes, contact Yudiz Placement if you have not made this changes.</td></tr>"));
        }

        public void SendForgotPasswordEmail(string email, string username, string otp)
        {
            SendEmail(email, $"{Localizer["email_sub_forgot_password"].Value}", DesignEmail($"{Localizer["email_sub_forgot_password"].Value}", $@"<tr><td style=""font-weight: 500; color: #292929; font-family: 'Nunito', sans-serif;"">Hi {username},</td></tr><tr><td style="" line-height: 0px;"" height=""16""></td></tr><tr><td style=""font-family: 'Nunito', sans-serif;"">Your verification code is <b style=""font - size:20px; "">{otp}</b>.</td></tr><tr><td>Enter this code in our website or app to activate your {Localizer["app_name"].Value} account.</td></tr><tr><td style="" line-height: 0px;"" height=""32""></td></tr>"));
        }

        #endregion Send Account related mail

        #region Send Email

        private void SendEmail(string email, string subject, string body) => Messages.SendEmail(email, subject, body);

        #endregion Send Email

        #region Design Email

        private static string DesignEmail(string subject, string body)
        {
            // Generate response
            var response = @$"<!DOCTYPE htmlPUBLIC "" -//W3C//DTD XHTML 1.0 Transitional//EN"" ""http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd""><html xmlns=""http://www.w3.org/1999/xhtml""><head><meta http-equiv=""Content-Type"" content=""text/html; charset=UTF-8""/><meta name=""format-detection"" content=""telephone=no""><meta name=""viewport"" content=""width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;""><meta http-equiv=""X-UA-Compatible"" content=""IE=9; IE=8; IE=7; IE=EDGE""/><title>Yudiz Placement</title><link href=""https://fonts.googleapis.com/css2?family=Nunito:wght@400;700&display=swap"" rel=""stylesheet""><link href=""https://fonts.googleapis.com/css2?family=Merriweather:wght@700&display=swap"" rel=""stylesheet""></head><body leftmargin=""0"" topmargin=""0"" marginwidth=""0"" marginheight=""0"" offset=""0"" bgcolor=""#f5fafa"" yahoo=""fix"" style=""margin:0; padding:0; -webkit-text-size-adjust:none; -ms-text-size-adjust:none;""><table cellspacing=""0"" cellpadding=""0"" border=""0"" width=""100%"" class=""ReadMsgBody"" align=""center""style=""font-family: 'Nunito', sans-serif;"" bgcolor=""#f5fafa"" ><tr><td><table cellspacing=""0"" cellpadding=""0"" border=""0"" width=""600"" class=""col-600"" align=""center""style="" background: #f5fafa;""><tr><td style=""line-height: 0px;"" height=""20""></td></tr><tr><td align=""center""><a href="""" target=""_blank""><img src=""https://www.yudiz.com/wp-content/uploads/2019/10/yudiz-logo.png"" height=""66px""/></a></td></tr><tr><td style="" line-height: 0px;"" height=""20""></td></tr><tr><td style=""font-size: 16px; line-height: 22px; color: #424242;""><table class=""col-600"" width=""100%"" border=""0"" align=""center"" cellpadding=""0"" cellspacing=""0""style="" background: #FFFFFF; border-radius: 4px;""><tr><td align=""center"" height=""4""style=""font-size: 0; line-height: 4px; background: #F5B041; border-radius: 4px 4px 0 0;""></td></tr><tr><td style=""padding: 0 24px;""><table width=""100%"" border=""0"" align=""center"" cellpadding=""0"" cellspacing=""0""><tr><td style="" line-height: 0px;"" height=""28""></td></tr><tr><td align=""center""style=""font-size: 24px; line-height: 23px; color: #005093; font-weight: 700; font-family: 'Merriweather', serif;"">{subject}</td></tr><tr><td style="" line-height: 0px;"" height=""24""></td></tr>{body}<tr><td style="" line-height: 0px;"" height=""32""></td></tr><tr><td style=""font-family: 'Nunito', sans-serif;"">Thank You.</td></tr><tr><td style=""line-height: 0px;"" height=""12""></td></tr><tr><td style=""font-family: 'Nunito', sans-serif;"">Yudiz Placement,</td></tr><tr><tdstyle=""font-family: 'Nunito', sans-serif; font-size: 18px; line-height: 25px; color: #000000; font-weight: 700;""><b>Yudiz Placement</b></td></tr><tr><td style=""line-height: 0px;"" height=""24""></td></tr></table></td></tr><tr><td align=""center"" height=""4""style=""font-size: 0; line-height: 4px; background: #F5B041; border-radius: 0 0 4px 4px;"">line</td></tr></table></td></tr><tr><td style="" line-height: 0px;"" height=""16""></td></tr><tr><td align=""center"" style=""font-family: 'Nunito', sans-serif;"">Yudiz Placement. All rights reserved.</td></tr><tr><td style="" line-height: 0px;"" height=""16""></td></tr></table></td></tr><tr><td style="" line-height: 0px;"" height=""24""></td></tr><tr><td style="" line-height: 0px;"" height=""32""></td></tr></table></body></html>";

            return response;
        }

        #endregion Design Email

        #region Dispose

        public void Dispose() => GC.SuppressFinalize(this);

        #endregion Dispose
    }
}
