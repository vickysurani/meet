﻿using azara.api.Filter;
using azara.models.Entities;
using azara.models.Requests.ProductCategory;
using azara.models.Responses.Base;
using azara.models.Responses.ProductCategory;
using azara.repository;
using azara.security;
using Microsoft.AspNetCore.Mvc;

namespace azara.api.Helpers
{
    public class ProductCategoryHelpers : IDisposable
    {
        #region Constructor
        AzaraContext DbContext { get; set; }
        ICrypto Crypto { get; set; }

        public ProductCategoryHelpers(
            AzaraContext DbContext,
            ICrypto Crypto)
        {
            this.DbContext = DbContext;
            this.Crypto = Crypto;
        }

        #endregion

        #region 1. Insert Product Category

        public async Task<BaseResponse> ProductCategoryInsert([FromBody] ProductCategoryInsertRequest request)
        {
            if (DbContext.ProductList.Any(x => x.Name.ToLower().Equals(request.Name.ToLower())))
                return await Task.FromResult(new BaseResponse { IsSuccess = false, ErrorMessage = "error_name_exist" });

            await DbContext.AddRangeAsync(new ProductCategoryEntity
            {
                Name = request.Name
            });

            await DbContext.SaveChangesAsync();

            return new BaseResponse { IsSuccess = true };
        }

        #endregion

        #region 2. Update Category Product
        public async Task<ProductCategoryUpdateResponse> ProductCategoryUpdate([FromBody] ProductCategoryUpdateRequest request)
        {
            var product = DbContext.ProductList.FirstOrDefault(x => x.Id.ToString().Equals(request.Id.ToString()));

            if (product == null)
                throw new ApiException("error_product_category_not_found");

            // Validation for duplicate Name
            if (DbContext.ProductList.Any(x => x.Name.ToLower().Equals(request.Name.ToLower())))
                throw new ApiException("error_name_exist");

            product.Name = request.Name ?? product.Name;

            var response = new ProductCategoryUpdateResponse
            {
                Name = product.Name,
            };

            DbContext.SaveChanges();

            return response;
        }
        #endregion

        #region Dispose

        public void Dispose() => GC.SuppressFinalize(this);

        #endregion Dispose
    }
}
