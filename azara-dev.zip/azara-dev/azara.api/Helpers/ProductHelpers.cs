﻿using azara.api.Filter;
using azara.models.Entities;
using azara.models.Requests.Base;
using azara.models.Requests.Product;
using azara.models.Responses.Base;
using azara.models.Responses.Product;
using azara.repository;
using azara.security;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace azara.api.Helpers
{
    public class ProductHelpers : IDisposable
    {
        #region Constructor
        AzaraContext DbContext { get; set; }
        ICrypto Crypto { get; set; }

        public ProductHelpers(
            AzaraContext DbContext,
            ICrypto Crypto)
        {
            this.DbContext = DbContext;
            this.Crypto = Crypto;
        }

        #endregion

        #region Calculate Total Pages

        public static int CalculateTotalPages(
            int total,
            int? pageSize)
        {
            var pages = Convert.ToDecimal(total) / Convert.ToDecimal(pageSize);
            var response = pages < 1 ? 1 : Convert.ToInt32(Math.Ceiling(pages));

            return response;
        }

        #endregion Calculate Total Pages

        #region 1. Insert Product

        public async Task<BaseResponse> ProductInsert([FromBody] ProductInsertRequest request)
        {
            if (DbContext.ProductList.Any(x => x.Name.ToLower().Equals(request.Name.ToLower())))
                return await Task.FromResult(new BaseResponse { IsSuccess = false, ErrorMessage = "error_name_exist" });

            await DbContext.AddRangeAsync(new ProductListEntity
            {
                Image = request.Image,
                Name = request.Name,
                Description = request.Description,
                OriginalPrice = request.OriginalPrice,
                DiscountedPrice = request.DiscountedPrice,
                OfferLabel = request.OfferLabel,
                StoreId = request.StoreId,
                ProductCategoryId = request.ProductCategoryId,
                ModifiedBy = request.ModifiedBy
            });

            await DbContext.SaveChangesAsync();

            return new BaseResponse { IsSuccess = true };
        }

        #endregion

        #region 2. Update Product
        public async Task<ProductUpdateResponse> ProductUpdate([FromBody] ProductUpdateRequest request)
        {
            var product = DbContext.ProductList.FirstOrDefault(x => x.Id.ToString().Equals(request.Id.ToString()));

            if (product == null)
                throw new ApiException("error_product_not_found");

            // Validation for duplicate Name
            if (DbContext.ProductList.Any(x => x.Name.ToLower().Equals(request.Name.ToLower())))
                throw new ApiException("error_name_exist");

            product.Image = request.Image ?? product.Image;
            product.Name = request.Name ?? product.Name;
            product.Description = request.Description ?? product.Description;
            product.OriginalPrice = request.OriginalPrice;
            product.DiscountedPrice = request.DiscountedPrice;
            product.OfferLabel = request.OfferLabel ?? product.OfferLabel;
            product.StoreId = request.StoreId ?? product.StoreId;
            product.ProductCategoryId = request.ProductCategoryId ?? product.ProductCategoryId;
            product.ModifiedBy = request.ModifiedBy ?? product.ModifiedBy;

            var response = new ProductUpdateResponse
            {
                Image = product.Image,
                Name = product.Name,
                Description = product.Description,
                OriginalPrice = product.OriginalPrice,
                DiscountedPrice = product.DiscountedPrice,
                OfferLabel = product.OfferLabel,
                StoreId = product.StoreId,
                ProductCategoryId = product.ProductCategoryId,
                ModifiedBy = product.ModifiedBy
            };

            DbContext.SaveChanges();

            return response;
        }
        #endregion

        #region 3. Product Get By Id
        public async Task<ProductGetByIdResponse> ProductGetById([FromBody] BaseRequiredIdRequest request)
        {
            var product = await DbContext.ProductList.FirstOrDefaultAsync(x => x.Id.ToString().Equals(request.Id.ToString()));

            if (product == null)
                throw new ApiException("error_product_not_found");

            var response = new ProductGetByIdResponse
            {
                Image = product.Image,
                Name = product.Name,
                Description = product.Description,
                OriginalPrice = product.OriginalPrice,
                DiscountedPrice = product.DiscountedPrice,
                OfferLabel = product.OfferLabel,
                StoreId = product.StoreId,
                ProductCategoryId = product.ProductCategoryId,
                ModifiedBy = product.ModifiedBy
            };

            return response;
        }

        #endregion

        #region 4. Get Product List
        public async Task<PaginationResponse> ProductGetList([FromBody] PaginationRequest request)
        {
            var productList = (from P in DbContext.ProductList
                               join S in DbContext.Stores on P.StoreId equals S.Id
                               join PC in DbContext.ProductCategories on P.ProductCategoryId equals PC.Id
                               select new
                               {
                                   Id = P.Id,
                                   Image = P.Image,
                                   Name = P.Name,
                                   Descripition = P.Description,
                                   OriginalPrice = P.OriginalPrice,
                                   DiscountedPrice = P.DiscountedPrice,
                                   OfferLabel = P.OfferLabel,
                                   StoreName = S.Name,
                                   ProductCategoryName = PC.Name,
                                   ModifiedBy = P.ModifiedBy
                               }).ToList();

            if (productList == null)
                throw new ApiException("error_product_not_found");

            var total = productList.Count();
            var totalPages = ProductHelpers.CalculateTotalPages(total, request.PageSize);
            var eventPaginationList = productList.Skip(request.PageNo * request.PageSize).Take(request.PageSize);

            var response = new
            {
                Total = total,
                TotalPages = totalPages,
                PageSize = request.PageSize,
                Offset = request.PageNo,
                Details = eventPaginationList
            };

            return new PaginationResponse
            {
                Total = response.Total,
                TotalPages = response.Total,
                OffSet = response.Offset,
                Details = response.Details
            };

        }
        #endregion

        #region 4. Delete Product
        public async Task<BaseResponse> ProductDelete([FromBody] BaseIdRequest request)
        {
            var product = DbContext.ProductList.FirstOrDefault(x => x.Id.Equals(request.Id));

            DbContext.ProductList.Remove(product);

            DbContext.SaveChanges();
            return new BaseResponse { IsSuccess = true };
        }
        #endregion 

        #region Dispose

        public void Dispose() => GC.SuppressFinalize(this);

        #endregion Dispose
    }
}
