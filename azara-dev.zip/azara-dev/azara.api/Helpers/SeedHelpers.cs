﻿using azara.models.Configs;
using azara.models.Constants;
using azara.models.Entities;
using azara.repository;
using azara.security;
using Microsoft.Extensions.Options;

namespace azara.api.Helpers
{
    public class SeedHelpers
    {
        #region Constructor

        AzaraContext AzaraContext { get; set; }

        AdminConfigs AdminConfigs { get; set; }

        ICrypto Crypto { get; set; }

        public SeedHelpers(AzaraContext AzaraContext, ICrypto Crypto, IOptions<AdminConfigs> options)
        {
            this.AzaraContext = AzaraContext;
            this.Crypto = Crypto;
            AdminConfigs = options.Value;
        }

        #endregion

        public async Task Seed()
         {
            #region Admin Seed

            if(!AzaraContext.Admin.Any())
            {
                var admin = new AdminEntity
                {
                    Name = AdminConfigs.Name,
                    UserName = AdminConfigs.UserName,
                    EmailId = AdminConfigs.EmailId,
                    Mobile = AdminConfigs.Mobile,
                    Password = Crypto.EncryptPassword(AdminConfigs.Password),
                    //Created = SettingConsts.CurrentDateTime,
                };

                await AzaraContext.Admin.AddRangeAsync(admin);

                await AzaraContext.SaveChangesAsync();
            }

            #endregion
        }
    }
}
