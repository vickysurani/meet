﻿using azara.api.Filter;
using azara.models.Entities;
using azara.models.Requests.Base;
using azara.models.Requests.Store;
using azara.models.Responses.Base;
using azara.models.Responses.Store;
using azara.repository;
using azara.security;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace azara.api.Helpers
{
    public class StoreHelpers : IDisposable
    {
        #region Constructor
        AzaraContext DbContext { get; set; }
        ICrypto Crypto { get; set; }

        public StoreHelpers(
            AzaraContext DbContext,
            ICrypto Crypto)
        {
            this.DbContext = DbContext;
            this.Crypto = Crypto;
        }

        #endregion

        #region Calculate Total Pages

        public static int CalculateTotalPages(
            int total,
            int? pageSize)
        {
            var pages = Convert.ToDecimal(total) / Convert.ToDecimal(pageSize);
            var response = pages < 1 ? 1 : Convert.ToInt32(Math.Ceiling(pages));

            return response;
        }

        #endregion Calculate Total Pages

        #region 1. Insert Store

        public async Task<BaseResponse> StoreInsert([FromBody] StoreInsertRequest request)
        {
            if (DbContext.ProductList.Any(x => x.Name.ToLower().Equals(request.Name.ToLower())))
                return await Task.FromResult(new BaseResponse { IsSuccess = false, ErrorMessage = "error_name_exist" });

            await DbContext.AddRangeAsync(new StoreEntity
            {
                Name = request.Name,
                Image = request.Image,
                Location = request.Location,
                Address = request.Address,
                EmailId = request.EmailId,
                ContactNumber = request.ContactNumber
            });

            await DbContext.SaveChangesAsync();

            return new BaseResponse { IsSuccess = true };
        }

        #endregion

        #region 2. Update Store

        public async Task<StoreUpdateResponse> StoreUpdate([FromBody] StoreUpdateRequest request)
        {
            var store = DbContext.Stores.FirstOrDefault(x => x.Id.ToString().Equals(request.Id.ToString()));

            if (store == null)
                throw new ApiException("error_store_not_found");

            // Validation for duplicate Name
            if (DbContext.Stores.Any(x => x.Name.ToLower().Equals(request.Name.ToLower())))
                throw new ApiException("error_name_exist");


            store.Name = request.Name ?? store.Name;
            store.Image = request.Image ?? store.Image;
            store.Location = request.Location ?? store.Location;
            store.Address = request.Address ?? store.Address;
            store.EmailId = request.EmailId ?? store.EmailId;
            store.ContactNumber = request.ContactNumber ?? store.ContactNumber;

            var response = new StoreUpdateResponse
            {
                Name = store.Name,
                Image = store.Image,
                Location = store.Location,
                Address = store.Address,
                EmailId = store.EmailId,
                ContactNumber = store.ContactNumber
            };

            DbContext.SaveChanges();

            return response;


        }
        #endregion

        #region 3. Store Get By Id
        public async Task<StoreGetByIdResponse> StoreGetById([FromBody] BaseRequiredIdRequest request)
        {
            var store = await DbContext.Stores.FirstOrDefaultAsync(x => x.Id.ToString().Equals(request.Id.ToString()));

            if (store == null)
                throw new ApiException("error_store_not_found");

            var response = new StoreGetByIdResponse
            {
                Name = store.Name,
                Image = store.Image,
                Location = store.Location,
                Address = store.Address,
                EmailId = store.EmailId,
                ContactNumber = store.ContactNumber
            };

            return response;
        }

        #endregion

        #region 4. Get Store List
        public async Task<PaginationResponse> StoreGetList([FromBody] PaginationRequest request)
        {
            var storeList = DbContext.Stores.ToList();

            if (storeList == null)
                throw new ApiException("error_store_not_found");

            var total = storeList.Count();
            var totalPages = StoreHelpers.CalculateTotalPages(total, request.PageSize);
            var eventPaginationList = storeList.Skip(request.PageNo * request.PageSize).Take(request.PageSize);

            var response = new
            {
                Total = total,
                TotalPages = totalPages,
                PageSize = request.PageSize,
                Offset = request.PageNo,
                Details = eventPaginationList
            };

            return new PaginationResponse
            {
                Total = response.Total,
                TotalPages = response.Total,
                OffSet = response.Offset,
                Details = response.Details
            };

        }
        #endregion

        #region Dispose

        public void Dispose() => GC.SuppressFinalize(this);

        #endregion Dispose
    }
}
