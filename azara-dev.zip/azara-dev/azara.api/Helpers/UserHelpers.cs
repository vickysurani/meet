﻿using AutoMapper;
using azara.api.Filter;
using azara.models;
using azara.models.Constants;
using azara.models.Entities;
using azara.models.Requests.User;
using azara.models.Responses.Base;
using azara.models.Responses.User;
using azara.repository;
using azara.security;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace azara.api.Helpers
{
    public class UserHelpers : IDisposable
    {
        #region Constructor
        AzaraContext DbContext { get; set; }
        ICrypto Crypto { get; set; }
        IMapper Mapper { get; set; }

        public UserHelpers(
            AzaraContext DbContext,
            ICrypto Crypto,
            IMapper Mapper)
        {
            this.DbContext = DbContext;
            this.Crypto = Crypto;
            this.Mapper = Mapper;
        }

        #endregion

        #region 1. User Login

        public async Task<BaseResponse> Login(UserSignInRequest request)
        {
            try
            {
                // Encrt password
                var password = Crypto.EncryptPassword(request.Password);

                // Check Username
                if (!DbContext.User.Where(x => x.EmailId.Equals(request.EmailId.ToLower()) && !x.Deleted).Any())
                    return await Task.FromResult(new BaseResponse { IsSuccess = false, ErrorMessage = "error_account_not_found" });

                var user = await DbContext.User.FirstOrDefaultAsync(x =>
                                x.EmailId.Equals(request.EmailId.ToLower()) &&
                                x.Password.Equals(password) &&
                                !x.Deleted);

                if (user == null)
                    return await Task.FromResult(new BaseResponse { IsSuccess = false, ErrorMessage = "error_password_invalid" });

                //if (!user.Active)
                //    return await Task.FromResult(new BaseResponse { IsSuccess = false, ErrorMessage = "error_user_inactive" });

                //remove old token
                var tokenList = DbContext.UserAccessToken.Where(x => x.UserId.Equals(user.Id) && x.Purpose.Equals("Login"));
                DbContext.UserAccessToken.RemoveRange(tokenList);
                DbContext.SaveChanges();

                var uniqueId = Guid.NewGuid();
                // Generate New Token
                await DbContext.AddRangeAsync(new UserAccessTokenEntity
                {
                    UserId = user.Id,
                    Purpose = "Login",
                    UniqueId = uniqueId,
                    Created = SettingConsts.CurrentDateTime,
                    Modified = SettingConsts.CurrentDateTime
                });
                DbContext.SaveChanges();

                var response = new
                {
                    user.Id,
                    user.FirstName,
                    user.LastName,
                    user.EmailId,
                    user.EmailVerified,
                    user.MobileNumber,
                    user.Image,
                    user.Password,
                    Created = SettingConsts.CurrentDateTime,
                    Modified = SettingConsts.CurrentDateTime,
                    UniqueId = uniqueId.ToString()
                };
                return await Task.FromResult(new BaseResponse { IsSuccess = true, Data = JsonConvert.SerializeObject(response) });
            }
            catch (Exception ex)
            {
                return await Task.FromResult(new BaseResponse
                {
                    IsSuccess = false,
                    ErrorMessage = ex.Message,
                    Data = JsonConvert.SerializeObject(ex)
                });
            }
        }
        #endregion

        #region 2. User Sign Up
        public async Task<UserSignUpResponse> SignUp(UserSignUpRequest request)
        {
            // Check user exists or not
            if (DbContext.User.Any(x => x.EmailId.Equals(request.EmailId)))
                throw new ApiException("user_already_exists");

            await DbContext.User.AddAsync(new UserEntity
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                EmailId = request.EmailId,
                MobileNumber = request.MobileNumber,
                Image = request.Image,
                Password = Crypto.EncryptPassword(request.Password),
                ConfirmPassword = Crypto.EncryptPassword(request.ConfirmPassword),
                Created = SettingConsts.CurrentDateTime,
                Modified = SettingConsts.CurrentDateTime
            });

            await DbContext.SaveChangesAsync();
            var response = new UserSignUpResponse
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                EmailId = request.EmailId,
                MobileNumber = request.MobileNumber,
                Image = request.Image,
                Password = Crypto.EncryptPassword(request.Password),
                ConfirmPassword = Crypto.EncryptPassword(request.ConfirmPassword)
            };
            return response;

        }
        #endregion

        #region 3. User Forgot Password

        public async Task<BaseResponse> ForgotPassword(UserForgotPasswordRequest request)
        {
            try
            {
                // Remove Old Token
                var user = DbContext.User.FirstOrDefault(x => x.EmailId.Equals(request.EmailId));

                if (user == null)
                    return await Task.FromResult(new BaseResponse { IsSuccess = false, ErrorMessage = "error_email_not_found" });

                // Code for generate OTP
                var generator = new Random();
                var otp = generator.Next(0, 1000000).ToString("D6");

                user.Otp = otp;
                user.OtpExpireTime = DateTime.UtcNow.AddMinutes(3);

                DbContext.User.Attach(user);
                DbContext.Entry(user).Property(x => x.Otp).IsModified = true;
                DbContext.Entry(user).Property(x => x.OtpExpireTime).IsModified = true;
                DbContext.SaveChanges();

                var response = new { EmailId = user.EmailId, Otp = otp };

                return await Task.FromResult(new BaseResponse { IsSuccess = true, Data = JsonConvert.SerializeObject(response) });
            }
            catch (Exception ex)
            {
                return await Task.FromResult(new BaseResponse
                {
                    IsSuccess = false,
                    ErrorMessage = ex.Message,
                    Data = JsonConvert.SerializeObject(ex)
                });
            }
        }
        #endregion

        #region 4. User Otp Verify
        public async Task<BaseResponse> OtpVerify(UserOtpVerifyRequest request)
        {
            try
            {
                var user = DbContext.User.FirstOrDefault(x => x.EmailId.Equals(request.EmailId));

                if (user == null)
                    return await Task.FromResult(new BaseResponse { IsSuccess = false, ErrorMessage = "error_account_not_found" });

                if (!string.IsNullOrEmpty(user.EmailOtp) && !user.EmailOtp.Equals(request.Otp))
                    return await Task.FromResult(new BaseResponse { IsSuccess = false, ErrorMessage = "error_invalid_otp" });

                var dateDifference = (DateTime.UtcNow - user.EmailOtpExpiry).GetValueOrDefault().TotalMinutes;
                if (dateDifference >= 5)
                    return await Task.FromResult(new BaseResponse { IsSuccess = false, ErrorMessage = "error_otp_expired" });

                user.Modified = DateTime.UtcNow;
                user.EmailVerified = true;
                DbContext.SaveChanges();

                return await Task.FromResult(new BaseResponse { IsSuccess = true });
            }
            catch (Exception ex)
            {
                return await Task.FromResult(new BaseResponse
                {
                    IsSuccess = false,
                    ErrorMessage = ex.Message,
                    Data = JsonConvert.SerializeObject(ex)
                });
            }
        }
        #endregion

        #region 5. Reset Password

        public async Task<BaseResponse> ResetPassword(UserResetPasswordRequest request)
        {

            // Check user exists or not
            var user = DbContext.User.FirstOrDefault(x => x.EmailId.Equals(request.EmailId));

            if (user == null)
                throw new ApiException("error_account_not_found");

            if (!string.IsNullOrEmpty(user.Otp) && !user.Otp.Equals(request.Otp))
                throw new ApiException("error_invalid_otp");

            //var dateDifference = DateTime.UtcNow.AddMinutes(5);
            if (user.OtpExpireTime <= DateTime.UtcNow)
                throw new ApiException("error_otp_expired");

            user.Password = Crypto.EncryptPassword(request.Password);
            user.Modified = DateTime.UtcNow;

            DbContext.User.Attach(user);
            DbContext.Entry(user).Property(x => x.Password).IsModified = true;
            DbContext.Entry(user).Property(x => x.Modified).IsModified = true;
            DbContext.SaveChanges();

            return new BaseResponse { IsSuccess = true };
        }

        #endregion

        #region 6. Change Password

        public async Task<BaseResponse> ChangePassword(UserChangePasswordRequest request)
        {

            // Check user exists or not
            var isUserExists = DbContext.User.Any(x => x.Id.Equals(request.UserId));

            if (!isUserExists)
                return await Task.FromResult(new BaseResponse { IsSuccess = false, ErrorMessage = "error_account_not_found" });

            // Validate Current Password
            request.CurrentPassword = Crypto.EncryptPassword(request.CurrentPassword);
            var user = DbContext.User.FirstOrDefault(x =>
                            x.Id.Equals(request.UserId) &&
                            x.Password.Equals(request.CurrentPassword));

            if (user == null)
                return await Task.FromResult(new BaseResponse { IsSuccess = false, ErrorMessage = "error_current_password_invalid" });

            user.Password = Crypto.EncryptPassword(request.Password);
            user.Modified = SettingConsts.CurrentDateTime;
            user.ModifiedBy = request.UserId;

            DbContext.User.Attach(user);
            DbContext.Entry(user).Property(x => x.Password).IsModified = true;
            DbContext.Entry(user).Property(x => x.Modified).IsModified = true;
            DbContext.Entry(user).Property(x => x.ModifiedBy).IsModified = true;

            // Remove Old Token
            var tokenList = DbContext.UserAccessToken.Where(x =>
                                x.UserId.Equals(request.UserId) &&
                                x.Purpose.Equals("Login"));

            if (!tokenList.Any())
                return await Task.FromResult(new BaseResponse { IsSuccess = false, ErrorMessage = "error_token_expired" });

            DbContext.UserAccessToken.RemoveRange(tokenList);

            DbContext.SaveChanges();

            return await Task.FromResult(new BaseResponse { IsSuccess = true });
        }

        #endregion

        #region 7. Update Profile
        public async Task<UserUpdateProfileResponse> EditProfile(UserUpdateProfileRequest request)
        {
            // Get User
            var user = DbContext.User.FirstOrDefault(x => x.Id.ToString().ToLower().Equals(request.Id.ToLower()));

            if (user == null)
                throw new ApiException("error_account_not_found");

            user.FirstName = request.FirstName;
            user.LastName = request.LastName;
            user.EmailId = request.EmailId;
            user.MobileNumber = request.MobileNumber;
            user.ModifiedBy = Guid.Parse(request.Id);
            user.Modified = SettingConsts.CurrentDateTime;

            DbContext.User.Attach(user);
            DbContext.Entry(user).Property(x => x.FirstName).IsModified = true;
            DbContext.Entry(user).Property(x => x.LastName).IsModified = true;
            DbContext.Entry(user).Property(x => x.EmailId).IsModified = true;
            DbContext.Entry(user).Property(x => x.MobileNumber).IsModified = true;
            DbContext.Entry(user).Property(x => x.ModifiedBy).IsModified = true;
            DbContext.Entry(user).Property(x => x.Modified).IsModified = true;
            DbContext.SaveChanges();

            var response = new UserUpdateProfileResponse
            {
                //Id= admin.Id,
                FirstName = user.FirstName,
                LastName = user.LastName,
                EmailId = user.EmailId,
                MobileNumber = user.MobileNumber,
                UniqueId = request.UniqueId,
            };
            return response;
        }

        #endregion

        #region 8. Delete Token - Logout

        public async Task<BaseResponse> DeleteToken(UserDeleteTokenRequest request)
        {
            // Remove Old Token
            var tokenList = DbContext.UserAccessToken.Where(x =>
                                x.UserId.ToString().Equals(request.UserId) &&
                                x.UniqueId.ToString().Equals(request.UniqueId) &&
                                x.Purpose.Equals("Login"));

            if (!tokenList.Any())
                throw new ApiException("error_token_expired");

            DbContext.UserAccessToken.RemoveRange(tokenList);
            DbContext.SaveChanges();

            return new BaseResponse { IsSuccess = true };
        }

        #endregion

        #region Get User Profile

        public async Task<UserResponse> GetUserProfile(Guid userId)
        {
            var userData = await DbContext.User.FirstOrDefaultAsync(f => f.Id.Equals(userId) && !f.Active && !f.Deleted);

            if (userData == null)
                throw new ApiException("Invalid user");
            else
            {
                var userResponceData = new UserResponse();
                Mapper.Map(userData, userResponceData);
                return userResponceData;
            }
        }

        #endregion

        #region Dispose

        public void Dispose() => GC.SuppressFinalize(this);

        #endregion Dispose
    }
}
