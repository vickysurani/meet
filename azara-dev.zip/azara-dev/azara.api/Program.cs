using azara.api.Filter;
using azara.api.Helpers;
using azara.logs;
using azara.logs.implementations;
using azara.models;
using azara.models.Configs;
using azara.models.Constants;
using azara.notify;
using azara.notify.implementations;
using azara.notify.Models;
using azara.repository;
using azara.security;
using azara.security.Implementations;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Globalization;
using System.Text;

var builder = WebApplication.CreateBuilder(args);
ConfigurationManager configuration = builder.Configuration;


// Add services to the container.

//builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddMvc(option => option.EnableEndpointRouting = false);
builder.Services.AddHttpContextAccessor();
builder.Services.AddSession();
builder.Services.AddOptions();

//builder.Services.AddSwaggerGen();

#region JWT Authentication

var key = Encoding.ASCII.GetBytes(builder.Configuration["AuthConfigs:Key"]);
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = false,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["AuthConfigs:Issuer"],
        ValidAudience = builder.Configuration["AuthConfigs:Audiance"],
        IssuerSigningKey = new SymmetricSecurityKey(key),
        ClockSkew = TimeSpan.Zero
    };
});

#endregion JWT Authentication

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
});

builder.Services.AddMvc();

builder.Services.Configure<IISServerOptions>(options =>
{
    options.AutomaticAuthentication = false;
    options.MaxRequestBodySize = 300000000;
});

#region Swagger Configuration

builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Azara",
        Version = "v1",
        Description = "Azara API Gateway"
    });
});

#endregion Swagger Configuration

builder.Services.AddDbContext<AzaraContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("DatabaseConnection")));

#region Initialization of Configs.
//var smtp = builder.Configuration["EmailConfigs:SmtpAddress"];
//var email = builder.Configuration["EmailConfigs:Password"];

//var settings = builder.Configuration.GetSection("EmailConfigs").Get<EmailConfigs>();
builder.Services.Configure<EmailConfigs>(builder.Configuration.GetSection("EmailConfigs"));
builder.Services.Configure<AuthConfigs>(builder.Configuration.GetSection("AuthConfigs"));
builder.Services.Configure<AdminConfigs>(builder.Configuration.GetSection("AdminConfigs"));

#endregion

#region Registering Dependency Injections.

builder.Services.AddScoped<ILogManager, LogManager>();
builder.Services.AddSingleton<ICrypto, Crypto>();
builder.Services.AddScoped<IMessages, Messages>();
builder.Services.AddSingleton<ExceptionFilter>();
builder.Services.AddScoped<SeedHelpers>();

#endregion Registering Dependency Injections.

builder.Services.AddCors(opt =>
{
    opt.AddPolicy(name: "CorsPolicy", builder =>
    {
        builder.AllowAnyOrigin()
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});


builder.Services.AddControllers()
            .ConfigureApiBehaviorOptions(options =>
            {
                options.SuppressModelStateInvalidFilter = true;
                options.SuppressConsumesConstraintForFormFileParameters = true;
                options.SuppressInferBindingSourcesForParameters = true;
                options.SuppressMapClientErrors = true;
            });

#region Language Setup

builder.Services.AddLocalization(options => options.ResourcesPath = "Resources");
builder.Services.Configure<RequestLocalizationOptions>(options =>
{
    var supportedCultures = new[] { new CultureInfo(LanguageConsts.English) };
    options.DefaultRequestCulture = new RequestCulture(culture: LanguageConsts.English, uiCulture: LanguageConsts.English);
    options.SupportedCultures = supportedCultures;
    options.SupportedUICultures = supportedCultures;
    options.RequestCultureProviders.Insert(0, new CustomRequestCultureProvider(async context =>
    {
        var userLangs = context.Request.Headers["Accept-Language"].ToString();
        var firstLang = userLangs.Split(',').FirstOrDefault();
        return await Task.FromResult(new ProviderCultureResult(firstLang, firstLang));
    }));
});

#endregion

#region Mapper Setup

builder.Services.AddAutoMapper(typeof(MapperProfile));

#endregion

var app = builder.Build();

SeedDatabase();

app.UseSwagger().UseSwaggerUI(c =>
{
    c.SwaggerEndpoint($"/swagger/v1/swagger.json", "Azara API Gateway");
});

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseRouting();
app.UseCors("CorsPolicy");
app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
});
app.Run();

void SeedDatabase() //can be placed at the very bottom under app.Run()
{
    try
    {
        using var scope = app.Services.CreateScope();
        var dbInitializer = scope.ServiceProvider.GetRequiredService<SeedHelpers>();
        dbInitializer.Seed().Wait();
    }
    catch (Exception ex)
    {
        Console.WriteLine(ex);
    }
}
