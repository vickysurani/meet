﻿global using azara.client.Models.Const;
global using azara.client.Models.Shared;
global using Microsoft.AspNetCore.Components.Forms;
global using Newtonsoft.Json;
global using System.Net.Http.Headers;
global using azara.client.Models.Account.Request;
global using System.Text;
global using azara.client.Helpers;
global using azara.client.Models.Account.Response;
global using azara.client.Models.Base.Response;
global using azara.client.Services;
global using System.ComponentModel.DataAnnotations;
global using azara.client.Models.Base.Request;
global using azara.client.Models.ShopProduct.Response;
global using azara.client.Helpers.Generic;



