﻿namespace azara.client.Helpers
{
    public class AccountHelpers
    {
        #region Login API
        internal static async Task<dynamic> LoginAPI(LoginRequest loginRequest)
        {
            var ApiRequest = new LoginRequest
            {
                EmailId = loginRequest.EmailId,
                Password = loginRequest.Password
            };

            var url = $"{ApiEndPointConsts.Account.UserLogin}";
            var stringContent = new StringContent(JsonConvert.SerializeObject(ApiRequest), Encoding.Default , "application/json");
            var response = await Service.PostAPIWithoutToken(url, stringContent);
            if (response.meta.statusCode != StatusCodeConsts.Success)
            {
                return new CallAPIList()
                {
                    meta = response.meta,
                };
            }
            return new CallAPI()
            {
                meta = response.meta,
                data = response.data
            };
        }
        #endregion Login API

        #region SignUp API
        internal static async Task<dynamic> SignUPApi(SignUpRequest signUpRequest)
        {
            var url = $"{ApiEndPointConsts.Account.UserSignUp}";
            var stringContent = new StringContent(JsonConvert.SerializeObject(signUpRequest), Encoding.UTF8, "application/json");
            var response = await Service.PostAPIWithoutToken(url, stringContent);
            if (response.meta.statusCode != StatusCodeConsts.Success)
            {
                return new CallAPIList()
                {
                    meta = response.meta,
                };
            }
            return new CallAPI()
            {
                meta = response.meta,
                data = response.data
            };
        }
        #endregion SignUP API

        #region ChaangePassword API
        internal static async Task<dynamic> ChaangePasswordPApi(ChnagePasswordRequest chnagePassword)
        {
            var url = $"{ApiEndPointConsts.Account.ChangePassword}";
            var stringContent = new StringContent(JsonConvert.SerializeObject(chnagePassword), Encoding.UTF8, "application/json");
            var response = await Service.PostAPIWithToken(url, stringContent , TokenResponse.Token);
            if (response.meta.statusCode != StatusCodeConsts.Success)
            {
                return new CallAPIList()
                {
                    meta = response.meta,
                };
            }
            return new CallAPI()
            {
                meta = response.meta,
                data = response.data
            };
        }
        #endregion ChaangePassword API

        #region ForgotPassword API
        internal static async Task<dynamic> ForgotPasswordApi(ForgotPasswordRequest forgotPasswordRequest)
        {
            var url = $"{ApiEndPointConsts.Account.ForgotPassword}";
            var stringContent = new StringContent(JsonConvert.SerializeObject(forgotPasswordRequest), Encoding.UTF8, "application/json");
            var response = await Service.PostAPIWithoutToken(url, stringContent);
            if (response.meta.statusCode != StatusCodeConsts.Success)
            {
                return new CallAPIList()
                {
                    meta = response.meta,
                };
            }
            return new CallAPI()
            {
                meta = response.meta,
                data = response.data
            };
        }
        #endregion ForgotPassword API

        #region ContactUs API
        internal static async Task<dynamic> ContactUs(ContactUsRequest request)
        {
            var url = $"{ApiEndPointConsts.Account.ContactUs}";
            var stringContent = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
            var response = await Service.PostAPIWithoutToken(url, stringContent);
            if (response.meta.statusCode != StatusCodeConsts.Success)
            {
                return new CallAPIList()
                {
                    meta = response.meta,
                };
            }
            return new CallAPI()
            {
                meta = response.meta,
                data = response.data
            };
        }
        #endregion SignUP API

        #region LogOut API
        internal static async Task<dynamic> LogoutApi()
        {
            var url = $"{ApiEndPointConsts.Account.Logout}";
            var response = await Service.GetAPIWithToken(url, TokenResponse.Token);
            if (response.meta.statusCode != StatusCodeConsts.Success)
            {
                return new CallAPIList()
                {
                    meta = response.meta,
                };
            }
            return new CallAPI()
            {
                meta = response.meta,
                data = response.data
            };
        }
        #endregion ChaangePassword API

        #region Get Admin Profile Data API
        internal static async Task<dynamic> GetProfilApi()
        {
            var url = $"{ApiEndPointConsts.Account.GetProfile}";
            var response = await Services.Service.GetAPIWithToken(url, TokenResponse.Token);
            if (response.meta.statusCode != StatusCodeConsts.Success)
            {
                return new CallAPIList()
                {
                    meta = response.meta,
                };
            }
            return new CallAPI()
            {
                meta = response.meta,
                data = response.data
            };
        }
        #endregion
    }
}
