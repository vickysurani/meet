﻿
namespace azara.client.Helpers
{
    public class ShopProductHelpers
    {
        #region Product List API
        internal static async Task<dynamic> ShopProductList(ListRequest request)
        {
            var url = $"{ApiEndPointConsts.Product.ShopProductList}";
            var stringContent = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
            var response = await Service.PostAPIWithToken(url, stringContent, TokenResponse.Token);
            if (response.meta.statusCode != StatusCodeConsts.Success)
            {
                return new CallAPIList()
                {
                    meta = response.meta,
                };
            }
            return new CallAPI()
            {
                meta = response.meta,
                data = response.data
            };
        }
        #endregion  Product List API

        #region Product whithout List API
    internal static async Task<dynamic> ShopProductListWhithoutToken(ListRequest request)
    {
        var url = $"{ApiEndPointConsts.Product.ShopProductList}";
        var stringContent = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
        var response = await Service.PostAPIWithoutToken(url, stringContent);
        if (response.meta.statusCode != StatusCodeConsts.Success)
        {
            return new CallAPIList()
            {
                meta = response.meta,
            };
        }
        return new CallAPI()
        {
            meta = response.meta,
            data = response.data
        };
    }
    #endregion  
    }

}



