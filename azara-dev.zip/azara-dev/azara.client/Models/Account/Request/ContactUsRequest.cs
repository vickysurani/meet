﻿namespace azara.client.Models.Account.Request
{
    public class ContactUsRequest
    {
        public string Name { get; set; }

        public string EmailId { get; set; }

        public string Description { get; set; }
    }
}
