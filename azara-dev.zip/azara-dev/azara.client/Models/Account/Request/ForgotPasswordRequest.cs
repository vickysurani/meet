﻿namespace azara.client.Models.Account.Request
{
    public class ForgotPasswordRequest
    {
        [Required, RegularExpression(@"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$", ErrorMessage = "error_invalid_email")]
        public string EmailId { get; set; }
    }
}
