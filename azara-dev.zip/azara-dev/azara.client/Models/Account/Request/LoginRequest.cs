﻿using System.ComponentModel.DataAnnotations;

namespace azara.client.Models.Account.Request
{
    public class LoginRequest : PasswordRequest
    {
        [Required]
        public string EmailId { get; set; }
    }
}
