﻿using System.ComponentModel.DataAnnotations;

namespace azara.client.Models.Account.Request
{
    public class PasswordRequest
    {
        [Required(ErrorMessage = "error_password_required")]
        [DataType(DataType.Password)]
        [RegularExpression(@"^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$", ErrorMessage = "Password must contain the Alphabet, Digits and Special charaters with atleast 8 characters.")]
        [StringLength(128, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 8)]
        public string Password { get; set; }
    }
}
