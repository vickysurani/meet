﻿namespace azara.client.Models.Base.Request
{
    public class BaseRequiredIdRequest
    {
        public Guid Id { get; set; }
    }
}
