﻿namespace azara.client.Models.Base.Request
{
    public class DropDownIdRequest
    {
        public string Id { get; set; }
    }
}
