﻿namespace azara.client.Models.Base.Response
{
    public class BaseExportResponse
    {
        public string DownloadLink { get; set; }
    }
}
