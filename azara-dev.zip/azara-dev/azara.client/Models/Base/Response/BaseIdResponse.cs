﻿namespace azara.client.Models.Base.Response
{
    public class BaseIdResponse
    {
        public string Id { get; set; }
    }
}
