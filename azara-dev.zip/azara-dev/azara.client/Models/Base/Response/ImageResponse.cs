﻿namespace azara.client.Models.Base.Response
{
    public class ImageResponse
    {
        public string imageUrl { get; set; }

    }
}
