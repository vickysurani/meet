﻿namespace azara.client.Models.Base.Response
{
    public class TokenResponse
    {
        public static string Token { get; set; }
    }
}
