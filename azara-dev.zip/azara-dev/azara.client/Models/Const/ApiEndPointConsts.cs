﻿namespace azara.client.Models.Const
{
    public class ApiEndPointConsts
    {
        const string Version = "v1/";

        public const string BaseRoute = "https://localhost:7234/api/" + Version;

        public class Account
        {
            public const string UserLogin = BaseRoute + "user/sign_in";

            public const string UserSignUp = BaseRoute + "user/sign_up";

            public const string ChangePassword = BaseRoute + "user/change_password";

            public const string ForgotPassword = BaseRoute + "user/forgot_password";

            public const string ContactUs = BaseRoute + "contact_us/add";

            public const string Logout = BaseRoute + "user/logout";
            
            public const string GetProfile = BaseRoute + "user/profile";


        }

        public class Product
        {
            public const string ShopProductList = BaseRoute + "product/get_list";

        }
        
        public class Store
        {
            public const string StoreList = BaseRoute + "store/get_list";

        }
    }
}
