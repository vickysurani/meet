﻿namespace azara.client.Models.ShopProduct.Request
{
    public class ShopProductListRequest
    {
    }
}
