﻿namespace azara.client.Models.Store.Response
{
    public class StoreListResponseData
    {
        public string Name { get; set; }
        public string Image { get; set; }
        public string Location { get; set; }
        public string Address { get; set; }
        public string EmailId { get; set; }
        public string ContactNumber { get; set; }
        public bool Active { get; set; }
        public bool Deleted { get; set; }
        public DateTime Created { get; set; }
        public DateTime Modified { get; set; }
        public string Id { get; set; }
    }

    public class StoreListResponse
    {
        public List<StoreListResponseData> Details { get; set; }
    }
}
