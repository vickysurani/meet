using azara.client;
using Blazored.LocalStorage;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.JSInterop;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) });
builder.Services.AddWMBSC(false);
builder.Services.AddBlazoredLocalStorage();
builder.Services.AddScoped<IDataService, DataService>(); 
builder.Services.AddOptions();
builder.Services.AddAuthorizationCore();
builder.Services.AddScoped<IHttpContextAccessor, HttpContextAccessor>();

var host = builder.Build();
var jsInterop = host.Services.GetRequiredService<IJSRuntime>();
await host.RunAsync();


