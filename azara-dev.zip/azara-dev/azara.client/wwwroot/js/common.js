﻿//$(document).ready(function () {
//    $('.categories-slick').slick({
//        dots: false,
//        autoplay: true,
//        infinite: true,
//        speed: 800,
//        cssEase: 'linear',
//        arrows: true,
//        slidesToShow: 6,
//        slidesToScroll: 1,
//        rows: 2,
//        responsive: [
//            {
//                breakpoint: 360,
//                settings: {
//                    slidesToShow: 2,
//                    arrows: false,
//                }
//            },
//            {
//                breakpoint: 768,
//                settings: {
//                    slidesToShow: 3,
//                    arrows: false,
//                    rows: 2,
//                }
//            },
//            {
//                breakpoint: 992,
//                settings: {
//                    slidesToShow: 4,
//                    rows: 2
//                }
//            },
//            {
//                breakpoint: 9999,
//                settings: {
//                    slidesToShow: 5,
//                    rows: 2
//                }
//            }
//        ]
//    });
//});

