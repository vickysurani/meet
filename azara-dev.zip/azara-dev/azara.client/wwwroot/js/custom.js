$(document).ready(function () {
    // Main Navigation Side Menu 
    $('.custom-toggle-bar').on('click', function () {
        $("html").toggleClass("overflow-hidden");
        $(".custom-main-section, header").toggleClass("move-to-left");
        $(".custom-toggle-bar").toggleClass("toggle-close-bar");
        $(".modal-backdrop").toggleClass("custom-backdrop");
    });
});

