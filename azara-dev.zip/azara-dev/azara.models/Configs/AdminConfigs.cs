﻿namespace azara.models.Configs
{
    public class AdminConfigs
    {
        public string EmailId { get; set; }

        public string Name { get; set; }

        public string UserName { get; set; }

        public string Mobile { get; set; }

        public string Password { get; set; }

    }
}
