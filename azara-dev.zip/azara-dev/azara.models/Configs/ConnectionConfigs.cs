﻿namespace azara.models.Configs
{
    public class ConnectionConfigs
    {
        public string DatabaseConnection { get; set; }
    }
}
