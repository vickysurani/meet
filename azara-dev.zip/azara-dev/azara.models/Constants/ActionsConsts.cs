﻿namespace azara.models.Constants
{
    public class ActionsConsts
    {
        public const string ApiVersion = "api/v1";

        public class User
        {
            public const string UserSignUp = "user/sign_up";

            public const string UserLogin = "user/sign_in";

            public const string ChangePassword = "user/change_password";

            public const string ForgotPassword = "user/forgot_password";

            public const string ResetPassword = "user/reset_password";

            public const string OtpVerify = "user/otp_verify";

            public const string UserProfile = "user/profile";

            public const string UpdateProfile = "user/update_profile";

            public const string Logout = "user/logout";
        }

        public class Product
        {
            public const string InsertProduct = "product/insert";

            public const string UpdateProduct = "product/update";

            public const string ProductGetById = "product/get_by_id";

            public const string ProductGetList = "product/get_list";

            public const string ProductDelete = "product/delete";

            public const string UploadProductImage = "product/image";
        }

        public class ProductCategory
        {
            public const string InsertProductCategory = "product_category/insert";

            public const string UpdateProductCategory = "product_category/update";

            public const string ProductCategoryGetById = "product_category/get_by_id";

            public const string ProductCategoryGetList = "product_category/get_list";

            public const string ProductCategoryDelete = "product_category/delete";
        }

        public class Store
        {
            public const string InsertStore = "store/insert";

            public const string UpdateStore = "store/update";

            public const string StoreGetById = "store/get_by_id";

            public const string StoreGetList = "store/get_list";

            public const string StoreDelete = "store/delete";
        }

        public class Blog
        {
            public const string InsertBlog = "blog/insert";

            public const string GetBlogList = "blog/get_list";

            public const string DeleteBlog = "blog/delete";
        }

        public class Advertisement
        {
            public const string InsertAdvertisement = "advertisement/insert";

            public const string UpdateAdvertisement = "advertisement/update";

            public const string GetAdvertisementList = "advertisement/get_list";

            public const string DeleteAdvertisement = "advertisement/delete";
        }

        public class ContactUs
        {
            public const string AddContactUs = "contact_us/add";
        }

        public class Admin
        {
            public const string AdminLogin = "admin/login";

            public const string ForgotPassword = "admin/forgot_password";

            public const string ResetPassword = "admin/reset_password";

            public const string Logout = "admin/logout";
        }
    }
}
