﻿namespace azara.models.Constants;
public class LanguageConsts
{
    public const string English = "en-US";

    public const string Hindi = "en-HI";
}

