﻿namespace azara.models.Constants;
public static class SettingConsts
{
    public static DateTime CurrentDateTime = DateTime.UtcNow;
}
