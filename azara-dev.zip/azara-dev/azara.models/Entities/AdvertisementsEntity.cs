﻿using azara.models.Entities.Base;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace azara.models.Entities
{
    public class AdvertisementsEntity : BaseEntity
    {
        [Required]
        public string AdvertisementTitle { get; set; }

        [Required]
        public string AdvertisementBannerImage { get; set; }

        public string Description { get; set; }

        public Guid? StoreId { get; set; }

        [ForeignKey("StoreId")]
        public StoreEntity StoreEntity { get; set; }
    }
}
