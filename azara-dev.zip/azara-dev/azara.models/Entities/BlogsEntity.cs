﻿using azara.models.Entities.Base;
using System.ComponentModel.DataAnnotations;

namespace azara.models.Entities
{
    public class BlogsEntity : BaseIdEntity
    {
        [Required]
        public string Image { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        public DateTime PublishedDate { get; set; }

        [Required]
        public string AuthorName { get; set; }

        public string Descriptions { get; set; }

        [Required]
        public DateTime Created { get; set; }
    }
}
