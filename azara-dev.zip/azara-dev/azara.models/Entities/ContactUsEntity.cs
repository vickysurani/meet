﻿using azara.models.Entities.Base;
using System.ComponentModel.DataAnnotations;

namespace azara.models.Entities
{
    public class ContactUsEntity : BaseIdEntity
    {
        [Required]
        public string Name { get; set; }

        [Required]
        public string EmailId { get; set; }

        public string Description { get; set; }
    }
}
