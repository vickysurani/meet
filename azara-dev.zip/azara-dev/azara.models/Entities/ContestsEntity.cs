﻿using azara.models.Entities.Base;
using System.ComponentModel.DataAnnotations;

namespace azara.models.Entities
{
    public class ContestsEntity : BaseEntity
    {
        [Required]
        public string Name { get; set; }

        public string Image { get; set; }

        public string Description { get; set; }

        [Required]
        public string ContestType { get; set; }
        
        [Required]
        public string Location { get; set; }


    }
}
