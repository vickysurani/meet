﻿using azara.models.Entities.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace azara.models.Entities
{
    public class CouponsEntity : BaseEntity
    {
        [Required]
        public string CouponTitle { get; set; }

        [Required]
        public string CouponImage { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        public decimal Amount { get; set; }

        [Required]
        public string CouponCode { get; set; }

    }
}
