﻿using azara.models.Entities.Base;
using System.ComponentModel.DataAnnotations;

namespace azara.models.Entities
{
    public class EventsEntity : BaseEntity
    {
        [Required]
        public string Name { get; set; }

        [Required]
        public DateTime? EventDate { get; set; }

        [Required]
        public DateTime? EventTime { get; set; }

        [Required]
        public string EventLocation { get; set; }

        [Required]
        public string Description { get; set; }
    }
}
