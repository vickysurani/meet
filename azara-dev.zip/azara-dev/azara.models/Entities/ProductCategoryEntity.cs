﻿using azara.models.Entities.Base;
using System.ComponentModel.DataAnnotations;

namespace azara.models.Entities
{
    public class ProductCategoryEntity : BaseEntity
    {
        [Required]
        public string Name { get; set; }
    }
}
