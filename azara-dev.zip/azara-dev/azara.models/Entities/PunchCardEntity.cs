﻿using azara.models.Entities.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace azara.models.Entities
{
    public class PunchCardEntity : BaseEntity
    {
        [Required]
        public string AvailablePunchCardPromo { get; set; }

        [Required]
        public string UsedPunchCardPromo { get; set; }

        [Required]
        public string RemainingPunchCardPromo { get; set; }

        [Required]
        public string PunchCardName { get; set; }

        public string Promocode { get; set; }

        [Required]
        public string Description { get; set; }

    }
}
