﻿using azara.models.Entities.Base;
using System.ComponentModel.DataAnnotations;

namespace azara.models.Entities
{
    public class RewardsEntity :BaseEntity
    {
        [Required]
        public string Name { get; set; }

        [Required]
        public string AvailableRewards { get; set; }

        [Required]
        public string UsedRewards { get; set; }

        [Required]
        public string RemainingRewards { get; set; }
    }
}
