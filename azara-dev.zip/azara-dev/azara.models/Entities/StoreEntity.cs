﻿using azara.models.Entities.Base;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace azara.models.Entities
{
    public class StoreEntity : BaseEntity
    {
        [Required, MaxLength(100)]
        public string Name { get; set; }

        public string Image { get; set; }

        public string Location { get; set; }

        [Required, MaxLength(500)]
        public string Address { get; set; }

        [Required, MaxLength(250)]
        public string EmailId { get; set; }

        [Required, MaxLength(20)]
        public string ContactNumber { get; set; }
    }
}
