﻿using azara.models.Entities.Base;
using System.ComponentModel.DataAnnotations;

namespace azara.models.Entities
{
    public class UserEntity : BaseEntity
    {
        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        [Required, MaxLength(250)]
        public string EmailId { get; set; }

        public bool EmailVerified { get; set; } = false;

        [MaxLength(7)]
        public string? EmailOtp { get; set; }

        public DateTime? EmailOtpExpiry { get; set; }

        public string? MobileNumber { get; set; }

        public string? Image { get; set; }

        [Required]
        public string Password { get; set; }

        [Required]
        public string ConfirmPassword { get; set; }

        [MaxLength(10)]
        public string? Otp { get; set; }

        public DateTime? OtpExpireTime { get; set; }

        [Required]
        public bool Active { get; set; }

        [Required]
        public bool Deleted { get; set; }

        [Required]
        public DateTime Created { get; set; }

        [Required]
        public DateTime Modified { get; set; }

        [Required]
        public Guid CreatedBy { get; set; }

        [Required]
        public Guid ModifiedBy { get; set; }
    }
}
