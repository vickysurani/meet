﻿using AutoMapper;
using azara.models.Entities;
using azara.models.Responses.User;

namespace azara.models
{
    public class MapperProfile : Profile
    {
        public MapperProfile()
        {
            CreateMap<UserEntity, UserResponse>();
        }
    }
}
