﻿namespace azara.models.Requests.Admin
{
    public class AdminDeleteTokenRequest
    {
        public string AdminId { get; set; }

        public string UniqueId { get; set; }
    }
}
