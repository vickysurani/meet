﻿using azara.models.Requests.Base;
using System.ComponentModel.DataAnnotations;

namespace azara.models.Requests.Advertisement
{
    public class AdvertisementInsertRequest : BaseIdRequest
    {
        [Required(ErrorMessage = "error_title_required")]
        public string AdvertisementTitle { get; set; }

        public string AdvertisementBannerImage { get; set; }

        public string Description { get; set; }

        public Guid? StoreId { get; set; }
    }
}
