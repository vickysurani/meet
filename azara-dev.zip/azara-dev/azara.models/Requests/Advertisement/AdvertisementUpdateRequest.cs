﻿using azara.models.Requests.Base;

namespace azara.models.Requests.Advertisement
{
    public class AdvertisementUpdateRequest : BaseIdRequest
    {
        public string AdvertisementTitle { get; set; }

        public string AdvertisementBannerImage { get; set; }

        public string Description { get; set; }

        public Guid? StoreId { get; set; }
    }
}
