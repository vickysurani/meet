﻿using System.Text.Json.Serialization;

namespace azara.models.Requests.Base
{
    public class BaseModifiedByRequest : BaseIdRequest
    {
        [JsonIgnore]
        public string? ModifiedBy { get; set; }
    }
}
