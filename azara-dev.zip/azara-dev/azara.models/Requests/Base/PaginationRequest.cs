﻿namespace azara.models.Requests.Base;

public class PaginationRequest
{
    public int PageNo { get; set; }
    public int PageSize { get; set; }
}
