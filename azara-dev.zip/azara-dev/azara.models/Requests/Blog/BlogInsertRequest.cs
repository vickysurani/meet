﻿using azara.models.Requests.Base;

namespace azara.models.Requests.Blog
{
    public class BlogInsertRequest : BaseIdRequest
    {
        public string Image { get; set; }

        public string Title { get; set; }

        public DateTime PublishedDate { get; set; }

        public string AuthorName { get; set; }

        public string Descriptions { get; set; }

        public DateTime Created { get; set; }
    }
}
