﻿using System.Text.Json.Serialization;

namespace azara.models.Requests.Common
{
    public class BaseValidateRequest
    {
        [JsonIgnore]
        public Guid? UserId { get; set; }

        [JsonIgnore]
        public string UniqueId { get; set; }
    }
}
