﻿using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace azara.models.Requests.Common
{
    public class FileUploadRequest : BaseValidateRequest
    {
        [JsonPropertyName("file")]
        [Required(ErrorMessage = "bad_response_file_required")]
        public IFormFile File { get; set; }
    }
    public class FileWithNameUploadRequest
    {
        [JsonPropertyName("file")]
        [Required(ErrorMessage = "bad_response_file_required")]
        public IFormFile File { get; set; }

        public string FileName { get; set; }
    }
}
