﻿using azara.models.Requests.Base;
using System.ComponentModel.DataAnnotations;

namespace azara.models.Requests.ProductCategory
{
    public class ProductCategoryInsertRequest : BaseIdRequest
    {
        [Required(ErrorMessage = "error_name_required")]
        public string Name { get; set; }
    }
}
