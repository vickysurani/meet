﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace azara.models.Requests.User
{
    public class UserChangePasswordRequest
    {
        [JsonIgnore]
        public Guid UserId { get; set; }

        [Required(ErrorMessage = "error_current_password_required")]
        [DataType(DataType.Password)]
        [RegularExpression(@"^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,30}$", ErrorMessageResourceName = "error_invalid_password_format")]
        public string CurrentPassword { get; set; }

        [Required(ErrorMessage = "error_password_required")]
        [DataType(DataType.Password)]
        [RegularExpression(@"^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,30}$", ErrorMessage = "error_invalid_password_format")]
        [StringLength(128, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 8)]
        public string Password { get; set; }


        [Required(ErrorMessageResourceName = "error_confirm_password_required")]
        [Compare("Password", ErrorMessageResourceName = "error_confirm_password_is_not_same_with_password")]
        public string ConfirmPassword { get; set; }
    }
}
