﻿namespace azara.models.Requests.User
{
    public class UserDeleteTokenRequest
    {
        public string UserId { get; set; }

        public string UniqueId { get; set; }
    }
}
