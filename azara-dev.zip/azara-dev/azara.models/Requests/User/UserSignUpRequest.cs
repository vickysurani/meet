﻿using System.ComponentModel.DataAnnotations;

namespace azara.models.Requests.User
{
    public class UserSignUpRequest
    {
        [Required(ErrorMessage = "error_first_name_required")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "error_last_name_required")]
        public string LastName { get; set; }

        [Required(ErrorMessageResourceName = "error_email_required")]
        [RegularExpression(@"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$", ErrorMessage = "error_invalid_email")]
        public string EmailId { get; set; }

        [RegularExpression(@"^[6-9]\d{9}$", ErrorMessage = "error_invalid_Mobile")]
        public string MobileNumber { get; set; }

        public string? Image { get; set; }

        [Required(ErrorMessage = "error_password_required")]
        [DataType(DataType.Password)]
        [RegularExpression(@"^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$", ErrorMessage = "error_invalid_password_format")]
        [StringLength(128, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 8)]
        public string Password { get; set; }


        [Required(ErrorMessageResourceName = "error_confirm_password_required")]
        [Compare("Password", ErrorMessageResourceName = "error_confirm_password_is_not_same_with_password")]
        public string ConfirmPassword { get; set; }
    }
}
