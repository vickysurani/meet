﻿using System.ComponentModel.DataAnnotations;

namespace azara.models.Requests.User
{
    public class UserUpdateProfileRequest
    {
        public string Id { get; set; }

        [Required(ErrorMessageResourceName = "error_first_name_required")]
        public string FirstName { get; set; }

        [Required(ErrorMessageResourceName = "error_last_name_required")]
        public string LastName { get; set; }

        [Required(ErrorMessageResourceName = "error_email_required")]
        public string EmailId { get; set; }

        [Required(ErrorMessageResourceName = "error_mobile_required")]
        public string MobileNumber { get; set; }

        public string UniqueId { get; set; }
    }
}
