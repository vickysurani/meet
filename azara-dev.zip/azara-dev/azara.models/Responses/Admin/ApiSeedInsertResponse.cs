﻿namespace azara.models.Responses.Admin
{
    public class ApiSeedInsertResponse
    {
        public bool IsNewAdmin { get; set; }
    }
}
