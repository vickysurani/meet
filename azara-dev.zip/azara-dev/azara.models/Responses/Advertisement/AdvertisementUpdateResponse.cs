﻿namespace azara.models.Responses.Advertisement
{
    public class AdvertisementUpdateResponse
    {
        public string AdvertisementTitle { get; set; }

        public string AdvertisementBannerImage { get; set; }

        public string Description { get; set; }

        public Guid? StoreId { get; set; }
    }
}
