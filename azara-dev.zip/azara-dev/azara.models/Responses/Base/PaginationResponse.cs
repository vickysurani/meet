﻿using System.Text.Json.Serialization;

namespace azara.models.Responses.Base;

public class PaginationResponse
{
    [JsonIgnore]
    public int Total { get; set; }

    [JsonIgnore]
    public int TotalPages { get; set; }

    [JsonIgnore]
    public int OffSet { get; set; }

    public dynamic Details { get; set; }
}
