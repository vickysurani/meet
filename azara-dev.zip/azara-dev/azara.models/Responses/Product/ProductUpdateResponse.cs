﻿namespace azara.models.Responses.Product
{
    public class ProductUpdateResponse
    {
        public string Image { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public decimal OriginalPrice { get; set; }

        public decimal DiscountedPrice { get; set; }

        public string OfferLabel { get; set; }

        public Guid? StoreId { get; set; }

        public Guid? ProductCategoryId { get; set; }

        public Guid? ModifiedBy { get; set; }
    }
}
