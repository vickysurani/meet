﻿namespace azara.models.Responses.ProductCategory;

public class ProductCategoryUpdateResponse
{
    public string Name { get; set; }
}
