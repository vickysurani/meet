﻿namespace azara.models.Responses.Store
{
    public class StoreUpdateResponse 
    {
        public string Name { get; set; }

        public string Image { get; set; }

        public string Location { get; set; }

        public string Address { get; set; }

        public string EmailId { get; set; }

        public string ContactNumber { get; set; }
    }
}
