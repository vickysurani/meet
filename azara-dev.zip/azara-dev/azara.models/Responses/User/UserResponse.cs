﻿using azara.models.Responses.Base;

namespace azara.models.Responses.User
{
    public class UserResponse : BaseAuditResponse
    {
        public Guid Id { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string EmailId { get; set; }

        public bool EmailVerified { get; set; }

        public string MobileNumber { get; set; }

        public string Image { get; set; }

        public Guid CreatedBy { get; set; }

        public Guid ModifiedBy { get; set; }
    }
}
