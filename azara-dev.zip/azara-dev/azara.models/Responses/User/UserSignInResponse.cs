﻿using azara.models.Responses.Base;

namespace azara.models.Responses.User
{
    public class UserSignInResponse : BaseResponse
    {
        public string Id { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        //[Required(ErrorMessage = "bad_response_Email_required")]
        public string EmailId { get; set; }

        public bool EmailVerified { get; set; } = false;

        public string MobileNumber { get; set; }

        public string? Image { get; set; }

        //[Required(ErrorMessage = "bad_response_Password_required")]
        public string Password { get; set; }

        public string Token { get; set; }

        public string UniqueId { get; set; }
    }
}
