﻿using azara.models.Responses.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace azara.models.Responses.User
{
    public class UserUpdateProfileResponse : BaseAuditResponse
    {
        [JsonIgnore]
        public string? UserId { get; set; }

        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        [Required]
        public string EmailId { get; set; }

        [Required]
        public string MobileNumber { get; set; }

        public string UniqueId { get; set; }
    }
}
