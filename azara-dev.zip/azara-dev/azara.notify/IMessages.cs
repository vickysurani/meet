﻿using azara.models.Configs;

namespace azara.notify;
public interface IMessages : IDisposable
{
    void SendEmail(string email, string subject, string body);
}
