﻿using azara.notify.Models;
using Microsoft.Extensions.Options;

namespace azara.notify.implementations;
public class Messages : IMessages
{
    #region Object Declarations And Constructor

    private EmailConfigs EmailConfig { get; set; }

    public Messages(IOptions<EmailConfigs> EmailConfigOption)
    {
        this.EmailConfig = EmailConfigOption.Value;
    }

    #endregion

    /// <summary>
    /// Send an email.
    /// </summary>
    /// <param name="email">Received email id</param>
    /// <param name="subject">Mail Subject</param>
    /// <param name="body">Mail HTML body</param>
    public void SendEmail(string email, string subject, string body)
    {
        using SendEmailViaSmtp smtp = new(EmailConfig);
        smtp.Send(email, subject, body);
    }

    #region Dispose

    public void Dispose()
    {
        GC.SuppressFinalize(this);
    }

    #endregion
}
