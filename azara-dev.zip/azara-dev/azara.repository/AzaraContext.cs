﻿using azara.models.Entities;
using azara.models.Entities.Base;
using Microsoft.EntityFrameworkCore;

namespace azara.repository
{
    public class AzaraContext : DbContext
    {
        public AzaraContext(DbContextOptions<AzaraContext> options) : base(options) { }

        public new DbSet<TEntity> Set<TEntity>() where TEntity : BaseEntity => base.Set<TEntity>();

        public DbSet<UserEntity> User { get; set; }
        public DbSet<UserAccessTokenEntity> UserAccessToken { get; set; }
        public DbSet<ProductListEntity> ProductList { get; set; }
        public DbSet<ProductCategoryEntity> ProductCategories { get; set; }
        public DbSet<StoreEntity> Stores { get; set; }
        public DbSet<PunchCardEntity> PunchCards { get; set; }
        public DbSet<CouponsEntity> Coupons { get; set; }
        public DbSet<EventsEntity> Events { get; set; }
        public DbSet<ContestsEntity> Contests { get; set; }
        public DbSet<RewardsEntity> Rewards { get; set; }
        public DbSet<FacebookRewardSharingEntity> FacebookRewardSharings { get; set; }
        public DbSet<AdvertisementsEntity> Advertisements { get; set; }
        public DbSet<BlogsEntity> Blogs { get; set; }
        public DbSet<ContactUsEntity> ContactUs { get; set; }
        public DbSet<AdminEntity> Admin { get; set; }
        public DbSet<AdminAccessTokenEntity> AdminAccessToken { get; set; }
    }
}
